
export interface CoffeeProfile {
  acidity: number;
  bitterness: number;
  sweetness: number;
  body: number;
  aroma: string;
}

export interface CoffeeRecipe {
  ingredients: string[];
  steps: string[];
  ratio: string;
  brewTime: string;
  waterTemp: string;
  grindSize: string;
}

export interface CoffeeEntry {
  id: string;
  name: string;
  image: string;
  description: string;
  origin: string;
  category: "Espresso" | "Susu" | "Manual Brew" | "Dingin" | "Spesial" | "Non-Kopi";
  type: "Panas" | "Dingin" | "Keduanya";
  strength: number;
  profile: CoffeeProfile;
  recipe: CoffeeRecipe;
  history: string;
  tips: string[];
  caffeine: number;
  isSpecialty?: boolean;
}

export const COFFEE_DATA: CoffeeEntry[] = [
  {
    id: "espresso",
    name: "Espresso",
    image: "https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?q=80&w=800",
    description: "Inti dari budaya kopi, satu shot konsentrat penuh energi dan cita rasa mendalam.",
    origin: "Italia",
    category: "Espresso",
    type: "Panas",
    strength: 5,
    profile: { acidity: 3, bitterness: 4, sweetness: 2, body: 5, aroma: "Kuat, Intens, Cokelat Hitam" },
    recipe: {
      ingredients: ["18-20g Kopi Bubuk Halus", "36-40ml Air"],
      steps: ["Giling kopi dengan tekstur sangat halus", "Ratakan di dalam portafilter", "Tamp dengan tekanan stabil", "Ekstraksi selama 25-30 detik"],
      ratio: "1:2",
      brewTime: "25-30 detik",
      waterTemp: "93°C",
      grindSize: "Halus (Fine)"
    },
    history: "Ditemukan di Italia pada awal abad ke-20 untuk mempercepat proses penyeduhan kopi bagi pekerja.",
    tips: ["Gunakan biji kopi segar", "Pastikan mesin espresso sudah panas sebelum digunakan"],
    caffeine: 63
  },
  {
    id: "cappuccino",
    name: "Cappuccino",
    image: "https://images.unsplash.com/photo-1572442388796-11668a67e53d?q=80&w=800",
    description: "Keseimbangan sempurna antara espresso, susu panas (steamed milk), dan busa susu yang lembut.",
    origin: "Italia",
    category: "Susu",
    type: "Panas",
    strength: 3,
    profile: { acidity: 2, bitterness: 2, sweetness: 4, body: 4, aroma: "Creamy, Kacang Panggang" },
    recipe: {
      ingredients: ["1 shot Espresso", "60ml Susu Steamed", "60ml Busa Susu"],
      steps: ["Siapkan double espresso", "Steam susu hingga menghasilkan microfoam", "Tuang susu diikuti busa dengan rasio 1:1:1"],
      ratio: "1:1:1",
      brewTime: "2 menit",
      waterTemp: "65°C (Susu)",
      grindSize: "Halus (Fine)"
    },
    history: "Dinamai berdasarkan ordo biarawan Capuchin, yang warna jubahnya mirip dengan warna minuman ini.",
    tips: ["Busa susu harus tebal dan tahan lama"],
    caffeine: 63
  },
  {
    id: "latte",
    name: "Caffè Latte",
    image: "https://images.unsplash.com/photo-1541167760496-162955ed8a9f?q=80&w=800",
    description: "Kopi berbasis susu yang lembut dengan lapisan tipis microfoam di atasnya.",
    origin: "Italia",
    category: "Susu",
    type: "Keduanya",
    strength: 2,
    profile: { acidity: 1, bitterness: 2, sweetness: 5, body: 3, aroma: "Susu, Manis" },
    recipe: {
      ingredients: ["1 shot Espresso", "200ml Susu Steamed", "Sedikit busa susu"],
      steps: ["Tuangkan espresso ke dalam gelas besar", "Steam susu dengan aerasi minimal", "Tuangkan susu ke atas espresso secara perlahan"],
      ratio: "1:3 sampai 1:5",
      brewTime: "2 menit",
      waterTemp: "65°C",
      grindSize: "Halus (Fine)"
    },
    history: "Mulai populer di kedai kopi Amerika pada tahun 1980-an sebagai alternatif yang lebih ringan.",
    tips: ["Sangat cocok untuk latihan latte art"],
    caffeine: 63
  },
  {
    id: "americano",
    name: "Americano",
    image: "https://images.unsplash.com/photo-1551033406-611cf9a28f67?q=80&w=800",
    description: "Espresso yang diencerkan dengan air panas, memberikan rasa yang bersih dan ringan.",
    origin: "Italia / AS",
    category: "Espresso",
    type: "Keduanya",
    strength: 3,
    profile: { acidity: 3, bitterness: 3, sweetness: 2, body: 2, aroma: "Bersih, Kayu" },
    recipe: {
      ingredients: ["Double Shot Espresso", "Air Panas"],
      steps: ["Tuangkan espresso ke dalam cangkir", "Tambahkan air panas (biasanya rasio 1:2)"],
      ratio: "1:2",
      brewTime: "1 menit",
      waterTemp: "90°C",
      grindSize: "Halus (Fine)"
    },
    history: "Tentara Amerika di Perang Dunia II mengencerkan espresso Italia agar mirip dengan kopi drip di rumah.",
    tips: ["Tuang air ke espresso untuk menjaga lapisan crema"],
    caffeine: 126
  },
  {
    id: "matcha-latte",
    name: "Matcha Latte",
    image: "https://images.unsplash.com/photo-1515823064-d6e0c04616a7?q=80&w=800",
    description: "Bubuk teh hijau Jepang premium yang dicampur dengan susu creamy.",
    origin: "Jepang",
    category: "Non-Kopi",
    type: "Keduanya",
    strength: 2,
    profile: { acidity: 1, bitterness: 2, sweetness: 4, body: 4, aroma: "Earthy, Rumput Segar" },
    recipe: {
      ingredients: ["1 sdt Bubuk Matcha", "30ml Air Panas", "200ml Susu", "Madu/Sirup (Opsional)"],
      steps: ["Aduk matcha dengan air panas hingga tidak menggumpal", "Panaskan dan steam susu", "Tuangkan susu ke dalam matcha"],
      ratio: "1:7",
      brewTime: "3 menit",
      waterTemp: "80°C",
      grindSize: "Bubuk"
    },
    history: "Berasal dari tradisi upacara teh Jepang yang kemudian diadaptasi menjadi minuman modern.",
    tips: ["Gunakan pengocok bambu (chasen) untuk hasil maksimal"],
    caffeine: 70
  },
  {
    id: "hot-chocolate",
    name: "Classic Hot Chocolate",
    image: "https://images.unsplash.com/photo-1544787210-22c954d7ca8e?q=80&w=800",
    description: "Minuman cokelat mewah yang dibuat dari kakao asli dan susu murni.",
    origin: "Meksiko",
    category: "Non-Kopi",
    type: "Panas",
    strength: 1,
    profile: { acidity: 1, bitterness: 2, sweetness: 5, body: 5, aroma: "Cokelat Kaya, Vanilla" },
    recipe: {
      ingredients: ["30g Bubuk Cokelat/Cokelat Batang", "250ml Susu", "Sedikit Garam", "Marshmallow (Opsional)"],
      steps: ["Lelehkan cokelat dengan sedikit susu panas", "Tambahkan sisa susu sambil diaduk", "Sajikan dengan topping favorit"],
      ratio: "1:8",
      brewTime: "4 menit",
      waterTemp: "70°C",
      grindSize: "N/A"
    },
    history: "Bangsa Maya adalah yang pertama menciptakan minuman cokelat ribuan tahun lalu.",
    tips: ["Gunakan cokelat dengan kadar kakao minimal 60%"],
    caffeine: 5
  },
  {
    id: "oreo-milkshake",
    name: "Oreo Milkshake",
    image: "https://images.unsplash.com/photo-1572442388796-11668a67e53d?q=80&w=800",
    description: "Perpaduan dingin dan manis antara es krim vanilla, susu, dan biskuit Oreo.",
    origin: "Amerika Serikat",
    category: "Non-Kopi",
    type: "Dingin",
    strength: 0,
    profile: { acidity: 0, bitterness: 1, sweetness: 5, body: 5, aroma: "Cookies and Cream" },
    recipe: {
      ingredients: ["3 scoop Es Krim Vanilla", "150ml Susu Dingin", "4 keping Oreo", "Whipping Cream"],
      steps: ["Blender es krim, susu, dan 3 keping Oreo", "Tuang ke gelas", "Hias dengan whipping cream dan remahan Oreo"],
      ratio: "N/A",
      brewTime: "2 menit",
      waterTemp: "Dingin",
      grindSize: "N/A"
    },
    history: "Milkshake mulai populer di awal abad ke-20 seiring dengan berkembangnya mesin blender.",
    tips: ["Jangan blender terlalu lama agar tekstur Oreo masih terasa"],
    caffeine: 0
  },
  {
    id: "v60",
    name: "V60 / Pour Over",
    image: "https://images.unsplash.com/photo-1544787210-22c954d7ca8e?q=80&w=800",
    description: "Standar emas untuk kopi spesialti, menonjolkan aroma dan kejernihan rasa melalui metode tuang manual.",
    origin: "Jepang",
    category: "Manual Brew",
    type: "Keduanya",
    strength: 2,
    profile: { acidity: 5, bitterness: 1, sweetness: 4, body: 2, aroma: "Floral, Buah, Seperti Teh" },
    recipe: {
      ingredients: ["15g Biji Kopi", "250g Air"],
      steps: ["Bilas filter kertas", "Bloom selama 30 detik", "Tuang air secara melingkar perlahan hingga target tercapai"],
      ratio: "1:17",
      brewTime: "2:30-3:00 menit",
      waterTemp: "92-96°C",
      grindSize: "Medium Fine"
    },
    history: "Diperkenalkan oleh Hario pada tahun 2004, didesain dengan sudut 60 derajat untuk aliran yang optimal.",
    tips: ["Gunakan teko leher angsa untuk kontrol tuangan yang presisi"],
    caffeine: 100,
    isSpecialty: true
  },
  {
    id: "gula-aren",
    name: "Kopi Susu Gula Aren",
    image: "https://images.unsplash.com/photo-1594631252845-29fc4586d5d7?q=80&w=800",
    description: "Favorit modern Indonesia: gabungan espresso, susu, dan gula aren cair yang legit dan gurih.",
    origin: "Indonesia",
    category: "Susu",
    type: "Dingin",
    strength: 3,
    profile: { acidity: 2, bitterness: 2, sweetness: 5, body: 4, aroma: "Gula Aren, Karamel" },
    recipe: {
      ingredients: ["Double Espresso", "150ml Susu Segar", "20ml Sirup Gula Aren", "Es Batu"],
      steps: ["Tuangkan sirup ke dasar gelas", "Tambahkan es batu", "Masukkan susu", "Tuangkan espresso di bagian paling atas"],
      ratio: "1:4",
      brewTime: "2 menit",
      waterTemp: "93°C",
      grindSize: "Halus (Fine)"
    },
    history: "Menjadi pemicu gelombang kopi kekinian di Indonesia sejak tahun 2017.",
    tips: ["Gunakan gula aren asli untuk aroma yang lebih kuat"],
    caffeine: 126
  },
  {
    id: "red-velvet-latte",
    name: "Red Velvet Latte",
    image: "https://images.unsplash.com/photo-1620353457065-f93ba9bb7097?q=80&w=800",
    description: "Minuman berwarna merah memikat dengan rasa cokelat lembut dan sentuhan vanilla yang manis.",
    origin: "Amerika Serikat",
    category: "Non-Kopi",
    type: "Keduanya",
    strength: 0,
    profile: { acidity: 1, bitterness: 1, sweetness: 5, body: 4, aroma: "Vanilla, Cokelat, Kue" },
    recipe: {
      ingredients: ["20g Bubuk Red Velvet", "200ml Susu Steamed", "Whipped Cream", "Taburan Cokelat"],
      steps: ["Campur bubuk red velvet dengan sedikit susu panas", "Aduk hingga merata", "Tuang sisa susu", "Hias dengan whipped cream"],
      ratio: "1:10",
      brewTime: "3 menit",
      waterTemp: "70°C",
      grindSize: "Bubuk"
    },
    history: "Terinspirasi dari kue Red Velvet yang populer di Amerika, diadaptasi menjadi minuman latte yang cantik.",
    tips: ["Sajikan hangat untuk rasa cokelat yang lebih intens"],
    caffeine: 0
  },
  {
    id: "thai-tea",
    name: "Traditional Thai Tea",
    image: "https://images.unsplash.com/photo-1558293842-c0fd3db86157?q=80&w=800",
    description: "Teh rempah khas Thailand yang berwarna oranye cerah dengan rasa manis dan creamy.",
    origin: "Thailand",
    category: "Non-Kopi",
    type: "Dingin",
    strength: 1,
    profile: { acidity: 1, bitterness: 2, sweetness: 5, body: 4, aroma: "Rempah, Teh Hitam, Anise" },
    recipe: {
      ingredients: ["20g Daun Teh Thai", "150ml Air Panas", "2 sdm Susu Kental Manis", "2 sdm Susu Evaporasi", "Es Batu"],
      steps: ["Seduh teh selama 5 menit", "Saring teh ke dalam gelas", "Tambahkan susu kental manis, aduk", "Beri es batu dan tuang susu evaporasi di atasnya"],
      ratio: "1:10",
      brewTime: "7 menit",
      waterTemp: "95°C",
      grindSize: "Daun Teh"
    },
    history: "Populer di Thailand sebagai minuman pelepas dahaga yang manis dan penuh rempah.",
    tips: ["Gunakan susu evaporasi merk berkualitas untuk rasa yang lebih gurih"],
    caffeine: 50
  },
  {
    id: "kalita-wave",
    name: "Kalita Wave",
    image: "https://images.unsplash.com/photo-1521017419142-f85af7195449?q=80&w=800",
    description: "Metode seduh tuang dengan dasar rata untuk ekstraksi yang lebih konsisten dan manis.",
    origin: "Jepang",
    category: "Manual Brew",
    type: "Panas",
    strength: 2,
    profile: { acidity: 3, bitterness: 2, sweetness: 4, body: 3, aroma: "Manis, Karamel, Seimbang" },
    recipe: {
      ingredients: ["20g Kopi", "300g Air"],
      steps: ["Bilas filter Kalita", "Tuang air perlahan dengan 3 tahap tuangan", "Pastikan aliran air tetap stabil di tengah"],
      ratio: "1:15",
      brewTime: "3:30 menit",
      waterTemp: "93°C",
      grindSize: "Medium"
    },
    history: "Diciptakan oleh perusahaan Kalita dari Jepang untuk memperbaiki kelemahan metode kerucut.",
    tips: ["Metode ini sangat pemaaf bagi pemula manual brew"],
    caffeine: 120,
    isSpecialty: true
  }
];

export const BEAN_DATA = [
  { id: "panama-geisha", name: "Panama Geisha", country: "Panama", altitude: "1700-1950m", process: "Washed / Natural", flavorNotes: ["Melati", "Bergamot", "Buah Tropis"], roastLevel: "Light", rarity: "Legendaris", priceTier: 5 },
  { id: "ethiopian-yirgacheffe", name: "Ethiopian Yirgacheffe", country: "Ethiopia", altitude: "1700-2200m", process: "Washed", flavorNotes: ["Lemon", "Floral", "Teh"], roastLevel: "Light-Medium", rarity: "Sangat Tinggi", priceTier: 3 },
  { id: "sumatra-mandheling", name: "Sumatra Mandheling", country: "Indonesia", altitude: "900-1600m", process: "Giling Basah", flavorNotes: ["Tanah", "Rempah", "Cokelat Hitam"], roastLevel: "Medium-Dark", rarity: "Menengah", priceTier: 2 },
  { id: "colombia-pink-bourbon", name: "Pink Bourbon Colombia", country: "Kolombia", altitude: "1800-2100m", process: "Honey", flavorNotes: ["Pomelo", "Madu", "Bunga Mawar"], roastLevel: "Light-Medium", rarity: "Langka", priceTier: 4 },
];
