
import React from 'react';
import { motion } from 'motion/react';
import { Search, Filter, SlidersHorizontal, ArrowRight, Info, Layers, Globe, MapPin } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { COFFEE_DATA } from '@/data/coffees';

const CATEGORIES = ["Semua", "Espresso", "Susu", "Manual Brew", "Dingin", "Spesial", "Non-Kopi"];

export function Encyclopedia() {
  const [searchTerm, setSearchTerm] = React.useState("");
  const [activeCategory, setActiveCategory] = React.useState("Semua");

  const filteredCoffees = COFFEE_DATA.filter(coffee => {
    const matchesSearch = coffee.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          coffee.origin.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === "Semua" || coffee.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-12">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div className="space-y-2">
          <Badge className="bg-brand-gold/10 text-brand-gold border-brand-gold/20 uppercase tracking-[0.2em] text-[10px] px-3 py-1 mb-2">
            Repositori Regional
          </Badge>
          <h1 className="text-6xl font-display font-medium tracking-tight italic leading-tight text-white">
            Arsip <span className="text-brand-gold">Dunia</span>
          </h1>
          <p className="text-white/40 max-w-lg font-light leading-relaxed">
            Menjelajahi lebih dari 100+ iterasi budaya biji kopi. Dari asal-usul bersejarah Etiopia hingga racikan spesialti kontemporer.
          </p>
        </div>
        
        <div className="relative w-full md:w-96 group">
           <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/20 group-focus-within:text-brand-gold transition-colors" />
           <Input 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari asal, sangrai, atau nama..." 
              className="pl-12 h-14 rounded-2xl bg-white/5 border-white/10 focus:border-brand-gold/50 focus:ring-0 transition-all font-light text-white shadow-xl"
           />
        </div>
      </div>

      {/* Category Bar */}
      <div className="bg-white/5 p-2 rounded-3xl border border-white/5 inline-flex flex-wrap gap-2 shadow-2xl">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-6 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${
              activeCategory === cat ? 'bg-brand-gold text-black shadow-lg shadow-brand-gold/20' : 'hover:bg-white/5 text-white/40'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Results Header */}
      <div className="flex items-center justify-between pb-4 border-b border-white/5">
         <div className="flex items-center gap-3">
            <Layers className="w-4 h-4 text-brand-gold" />
            <span className="text-[10px] uppercase tracking-widest font-black text-white/20">{filteredCoffees.length} ENTRI TERINDEKS</span>
         </div>
         <Button variant="ghost" size="sm" className="text-[10px] uppercase tracking-[0.2em] font-black text-white/40 hover:text-white">
           <SlidersHorizontal className="w-4 h-4 mr-2" /> URUTKAN: GEOGRAFIS
         </Button>
      </div>

      {/* Archive Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-10">
        {filteredCoffees.map((coffee, i) => (
          <motion.div
            key={coffee.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.03, duration: 0.5 }}
          >
            <Link to={`/coffee/${coffee.id}`}>
              <Card className="group bg-zinc-900 border border-white/5 hover:border-brand-gold/30 transition-all duration-500 rounded-[48px] overflow-hidden flex flex-col relative shadow-3xl">
                <div className="aspect-[3/4] overflow-hidden relative">
                  <img 
                    src={coffee.image} 
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 scale-100 group-hover:scale-110 brightness-75 group-hover:brightness-100" 
                    alt={coffee.name}
                  />
                  {/* Subtle Overlays */}
                  <div className="absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-black via-black/40 to-transparent pointer-events-none" />
                  
                  {/* Floating Data Labels */}
                  <div className="absolute top-8 left-8 flex flex-col gap-2 z-10">
                     <Badge className="bg-black/60 backdrop-blur-md text-brand-gold border border-white/10 uppercase text-[9px] font-black tracking-widest px-4 py-1.5 rounded-full">
                       {coffee.origin}
                     </Badge>
                     {coffee.isSpecialty && (
                        <Badge className="bg-brand-gold text-black border-none uppercase text-[9px] font-black tracking-widest px-4 py-1.5 rounded-full shadow-lg shadow-brand-gold/20">
                          SPESIALTI
                        </Badge>
                     )}
                  </div>

                  <div className="absolute bottom-12 left-10 right-10 z-10 flex flex-col items-center text-center">
                     <p className="text-[10px] text-brand-gold font-black uppercase tracking-[0.4em] mb-3 opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-500">{coffee.category}</p>
                     <h3 className="text-4xl font-display font-medium leading-none mb-2 text-white italic tracking-tighter">{coffee.name}</h3>
                     <div className="w-12 h-px bg-brand-gold/30 my-4 group-hover:w-full transition-all duration-700" />
                     <p className="text-white/30 text-[10px] uppercase font-black tracking-[0.2em] flex items-center gap-2 group-hover:text-white transition-colors">
                        <ArrowRight className="w-4 h-4 text-brand-gold" /> LIHAT ARSIP
                     </p>
                  </div>
                </div>
              </Card>
            </Link>
          </motion.div>
        ))}
      </div>

      {filteredCoffees.length === 0 && (
        <div className="py-32 text-center space-y-8 flex flex-col items-center">
           <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center border border-white/10 animate-pulse">
              <Globe className="w-12 h-12 text-white/10" />
           </div>
           <div className="space-y-3">
             <h3 className="text-3xl font-display italic text-white">Tidak ada data di kuadran ini</h3>
             <p className="text-white/30 font-light max-w-md">Asal atau sangrai yang Anda cari saat ini belum tersedia dalam koleksi digital kami.</p>
           </div>
           <button onClick={() => { setSearchTerm(""); setActiveCategory("Semua"); }} className="rounded-full bg-brand-gold text-black font-black text-[10px] tracking-[0.2em] px-12 h-14 shadow-xl shadow-brand-gold/20 border-none uppercase hover:scale-105 transition-transform">
              RESET PARAMETER
           </button>
        </div>
      )}
    </div>
  );
}
