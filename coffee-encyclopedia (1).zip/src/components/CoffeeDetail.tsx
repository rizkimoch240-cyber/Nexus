
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowLeft, Clock, Thermometer, Droplet, Coffee, Info, Star, ChevronRight, Share2, Heart, Globe, Activity, Shield, Hash, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { COFFEE_DATA } from '@/data/coffees';

export function CoffeeDetail() {
  const { id } = useParams();
  const coffee = COFFEE_DATA.find(c => c.id === id);

  if (!coffee) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center space-y-8 text-center px-6">
        <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center border border-white/5 animate-pulse">
          <Info className="w-12 h-12 text-white/10" />
        </div>
        <div className="space-y-3">
          <h1 className="text-5xl font-display italic text-white">Arsip Hilang</h1>
          <p className="text-white/30 font-light max-w-sm">Indeks catatan yang ditentukan tidak dapat ditemukan dalam buku besar kami.</p>
        </div>
        <Link to="/encyclopedia">
          <button className="rounded-full bg-brand-gold text-black font-black uppercase text-[10px] tracking-[0.2em] px-12 h-14 shadow-xl shadow-brand-gold/20 hover:scale-105 transition-transform">MUAT ULANG ARSIP</button>
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-0 -mt-12 -mx-12">
      {/* Immersive Header */}
      <section className="relative h-[85vh] flex items-end">
        <div className="absolute inset-0">
          <img 
            src={coffee.image} 
            className="w-full h-full object-cover grayscale brightness-[0.35]" 
            alt={coffee.name}
          />
          <div className="absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-black via-black/40 to-transparent" />
        </div>
        
        <div className="max-w-[1400px] mx-auto w-full px-12 relative z-10 pb-20">
          <Link to="/encyclopedia" className="inline-flex items-center gap-4 text-[10px] uppercase font-black tracking-[0.4em] text-white/40 hover:text-brand-gold transition-colors mb-16 group">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" /> KEMBALI KE BUKU BESAR
          </Link>
          
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-16">
            <div className="space-y-8">
               <div className="flex flex-wrap gap-4">
                 <Badge className="bg-brand-gold text-black border-none uppercase text-[10px] font-black tracking-[0.2em] px-5 py-2 rounded-full shadow-lg shadow-brand-gold/20">{coffee.category}</Badge>
                 <Badge className="bg-white/5 text-white/20 border border-white/10 uppercase text-[10px] font-black tracking-[0.2em] px-5 py-2 rounded-full">INDEKS: {coffee.id}</Badge>
               </div>
               <h1 className="text-8xl md:text-[11rem] font-display font-medium leading-[0.8] tracking-tighter italic text-white">{coffee.name}</h1>
               <div className="flex flex-wrap items-center gap-12 text-white/30 uppercase tracking-[0.4em] text-[10px] font-black pt-6">
                  <div className="flex items-center gap-4 group hover:text-brand-gold transition-colors cursor-default"><Globe className="w-5 h-5 text-brand-gold/60" /> {coffee.origin}</div>
                  <div className="flex items-center gap-4 group hover:text-brand-gold transition-colors cursor-default"><Activity className="w-5 h-5 text-brand-gold/60" /> INDEKS KEKUATAN: {coffee.strength}/05</div>
                  <div className="flex items-center gap-4 group hover:text-brand-gold transition-colors cursor-default"><Shield className="w-5 h-5 text-brand-gold/60" /> TERVERIFIKASI SCA</div>
               </div>
            </div>
            
            <div className="flex gap-6 mt-8 lg:mt-0">
               <button className="w-24 h-24 rounded-[40px] bg-white/5 border border-white/10 flex items-center justify-center text-white/30 hover:text-brand-gold hover:border-brand-gold/30 transition-all shadow-4xl group">
                 <Share2 className="w-7 h-7 group-hover:scale-110 transition-transform" />
               </button>
               <button className="h-24 px-16 rounded-[40px] bg-brand-gold text-black font-black uppercase text-[13px] tracking-[0.3em] shadow-4xl shadow-brand-gold/20 hover:scale-[1.05] active:scale-95 transition-all italic">
                 Mulai Urutan Seduh
               </button>
            </div>
          </div>
        </div>
      </section>

      {/* Content Grid */}
      <div className="max-w-[1400px] mx-auto px-12 py-40 grid grid-cols-1 lg:grid-cols-12 gap-24">
        {/* Main Dossier Column */}
        <div className="lg:col-span-8 space-y-40">
          {/* Executive Summary */}
          <section className="space-y-16">
             <div className="flex items-center gap-6">
                <div className="w-16 h-px bg-brand-gold" />
                <h2 className="text-[10px] uppercase tracking-[0.4em] text-brand-gold font-black">Ringkasan Eksekutif</h2>
             </div>
             <p className="text-5xl text-white font-light leading-snug italic pr-12 tracking-tighter">
               {coffee.description}
             </p>
             <div className="pt-24 grid grid-cols-2 md:grid-cols-4 gap-16">
                {[
                  { label: "Sensasi Mulut (Body)", val: coffee.profile.body },
                  { label: "Delta Keasaman", val: coffee.profile.acidity },
                  { label: "Kandungan Sukrosa", val: coffee.profile.sweetness },
                  { label: "Level Alkaloid", val: `${coffee.caffeine}mg` }
                ].map((s, i) => (
                  <div key={i} className="space-y-3 group border-l border-white/5 pl-8 hover:border-brand-gold transition-colors">
                     <div className="text-[10px] uppercase tracking-[0.2em] font-black text-white/20 group-hover:text-brand-gold transition-colors">{s.label}</div>
                     <div className="text-3xl font-display italic text-white leading-none tracking-widest">{s.val}</div>
                  </div>
                ))}
             </div>
          </section>

          {/* Historical Context */}
          <section className="bg-zinc-900 p-20 md:p-32 rounded-[80px] border border-white/5 space-y-12 relative overflow-hidden group shadow-4xl">
             <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-brand-gold/5 blur-[120px] -mr-48 -mt-48 rounded-full" />
             <div className="flex items-center gap-5 relative z-10">
                <div className="w-10 h-10 rounded-2xl bg-brand-gold/10 flex items-center justify-center">
                  <Hash className="w-5 h-5 text-brand-gold/60" />
                </div>
                <h2 className="text-[10px] uppercase tracking-[0.4em] text-white/20 font-black">Buku Besar Sejarah</h2>
             </div>
             <p className="text-4xl text-white font-display italic leading-relaxed relative z-10 pr-6 tracking-tight">
               "{coffee.history}"
             </p>
             <div className="pt-10 border-t border-white/5 inline-flex items-center gap-4 relative z-10">
                <div className="w-2.5 h-2.5 rounded-full bg-brand-gold shadow-[0_0_10px_rgba(212,175,55,0.5)]" />
                <span className="text-[10px] uppercase tracking-[0.3em] font-black text-white/10">Entri Arsip Terverifikasi</span>
             </div>
          </section>

          {/* Extraction Protocol */}
          <section className="space-y-20">
             <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/5 pb-12 gap-8">
                <div className="flex items-center gap-8">
                   <div className="w-20 h-20 rounded-[32px] bg-brand-gold/5 flex items-center justify-center text-brand-gold border border-brand-gold/10 shadow-inner group">
                      <Target className="w-10 h-10 opacity-60 group-hover:opacity-100 transition-opacity" />
                   </div>
                   <div className="space-y-2">
                      <h2 className="text-[10px] uppercase tracking-[0.4em] text-brand-gold font-black">Protokol Target</h2>
                      <p className="text-3xl font-display italic text-white">Lab Persiapan Sensorik</p>
                   </div>
                </div>
                <div className="flex items-center gap-12">
                   <div className="flex flex-col items-end">
                      <span className="text-[10px] uppercase tracking-[0.2em] text-white/10 font-black">Durasi Rendam</span>
                      <span className="text-2xl font-black italic tracking-widest text-white">{coffee.recipe.brewTime}</span>
                   </div>
                   <div className="flex flex-col items-end">
                      <span className="text-[10px] uppercase tracking-[0.2em] text-white/10 font-black">Set Termal</span>
                      <span className="text-2xl font-black italic tracking-widest text-white">{coffee.recipe.waterTemp}</span>
                   </div>
                </div>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-24">
                <div className="space-y-12">
                   <h3 className="text-[10px] uppercase tracking-[0.4em] font-black text-white/20 flex items-center gap-4">
                      <div className="w-2.5 h-2.5 rounded-full bg-brand-gold" /> Persyaratan Komponen
                   </h3>
                   <ul className="space-y-8">
                      {coffee.recipe.ingredients.map((ing, i) => (
                        <li key={i} className="flex items-center gap-8 group">
                           <div className="text-3xl font-display italic text-white/5 group-hover:text-brand-gold transition-colors duration-500">0{i+1}</div>
                           <span className="text-xl font-light text-white/30 group-hover:text-white transition-colors tracking-tight">{ing}</span>
                        </li>
                      ))}
                   </ul>
                </div>
                <div className="space-y-12">
                   <h3 className="text-[10px] uppercase tracking-[0.4em] font-black text-white/20 flex items-center gap-4">
                      <div className="w-2.5 h-2.5 rounded-full bg-brand-gold" /> Proses Berurutan
                   </h3>
                   <div className="space-y-8">
                      {coffee.recipe.steps.map((step, i) => (
                        <div key={i} className="bg-white/[0.02] p-10 rounded-[40px] border border-white/5 space-y-3 group hover:border-brand-gold/30 transition-all shadow-xl">
                           <span className="text-[10px] uppercase tracking-[0.3em] font-black text-brand-gold/30">Langkah Urutan 0{i+1}</span>
                           <p className="text-base text-white/30 leading-relaxed font-light group-hover:text-white/80 transition-colors">{step}</p>
                        </div>
                      ))}
                   </div>
                </div>
             </div>
          </section>
        </div>

        {/* Sidebar Station */}
        <div className="lg:col-span-4 space-y-20">
          {/* Sensory Map */}
          <div className="bg-zinc-900 p-12 rounded-[56px] border border-white/5 space-y-16 shadow-4xl relative overflow-hidden">
             <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-brand-gold/20 to-transparent" />
             <div className="flex items-center gap-4">
                <Activity className="w-5 h-5 text-brand-gold/60" />
                <h3 className="text-[10px] uppercase tracking-[0.4em] font-black text-white/30 italic">Pemetaan Sensorik</h3>
             </div>
             <div className="space-y-12">
                <ProfileStat label="Tingkat Keasaman" value={coffee.profile.acidity} />
                <ProfileStat label="Indeks Kepahitan" value={coffee.profile.bitterness} />
                <ProfileStat label="Kandungan Sakarin" value={coffee.profile.sweetness} />
                <ProfileStat label="Viskositas (Body)" value={coffee.profile.body} />
             </div>
             <div className="pt-12 border-t border-white/5 space-y-4">
                <span className="text-[10px] uppercase tracking-[0.3em] text-white/10 font-black">CATATAN OLFAKTORI UTAMA</span>
                <div className="text-5xl font-display font-medium text-brand-gold italic leading-none tracking-tighter">{coffee.profile.aroma}</div>
             </div>
          </div>

          {/* Expert Heuristics */}
          <div className="space-y-10">
             <div className="flex items-center gap-4 pl-4">
               <Target className="w-5 h-5 text-brand-gold/60" />
               <h3 className="text-[10px] uppercase tracking-[0.4em] font-black text-white/30 italic">Heuristik Barista</h3>
             </div>
             <div className="space-y-8">
                {coffee.tips.map((tip, i) => (
                  <div key={i} className="flex gap-8 p-10 rounded-[48px] bg-white/[0.02] border border-white/5 group hover:bg-brand-gold transition-all duration-500 shadow-2xl hover:shadow-brand-gold/20">
                     <Star className="w-7 h-7 text-brand-gold group-hover:text-black shrink-0 transition-all duration-500 group-hover:scale-125" />
                     <p className="text-base font-light text-white/30 group-hover:text-black leading-relaxed italic">{tip}</p>
                  </div>
                ))}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ProfileStat({ label, value }: { label: string, value: number }) {
  return (
    <div className="space-y-4 group">
      <div className="flex justify-between items-center text-[11px] uppercase tracking-[0.3em] font-black text-white/20 group-hover:text-white transition-colors">
        <span>{label}</span>
        <span className="text-brand-gold italic">{value}.0 / 5.0</span>
      </div>
      <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden shadow-inner">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${(value / 5) * 100}%` }}
          transition={{ duration: 1.8, ease: [0.22, 1, 0.36, 1] }}
          className="h-full bg-gradient-to-r from-brand-gold/40 to-brand-gold rounded-full shadow-[0_0_15px_rgba(212,175,55,0.3)]"
        />
      </div>
    </div>
  );
}

// No longer need fallback
