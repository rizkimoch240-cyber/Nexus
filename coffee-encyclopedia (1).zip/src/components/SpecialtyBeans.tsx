
import React from 'react';
import { motion } from 'motion/react';
import { Star, MapPin, TrendingUp, DollarSign, Award, ArrowUpRight, Zap, Globe, ShieldCheck, Activity } from 'lucide-react';
import { BEAN_DATA } from '@/data/coffees';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export function SpecialtyBeans() {
  return (
    <div className="space-y-20">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-end gap-10">
        <div className="space-y-4">
           <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-brand-gold/10 flex items-center justify-center">
                <Zap className="w-4 h-4 text-brand-gold" />
              </div>
              <span className="text-[10px] uppercase tracking-[0.4em] font-black text-white/30">Arsip Tingkat-1</span>
           </div>
           <h1 className="text-7xl font-display font-medium tracking-tight italic leading-[0.9] text-white">Manifesto <span className="text-brand-gold">Biji Kopi</span></h1>
           <p className="text-white/40 max-w-lg font-light leading-relaxed">
             Buku besar langsung dari panen paling elit di dunia. Setiap entri diverifikasi oleh protokol sensorik SCA dan standar lelang internasional.
           </p>
        </div>
        
        <div className="flex gap-8 items-center">
           <div className="flex flex-col items-end">
              <span className="text-[10px] uppercase opacity-30 tracking-[0.2em] font-black">Listing Aktif</span>
              <span className="text-4xl font-display text-brand-gold italic">2,482</span>
           </div>
           <div className="w-px h-12 bg-white/10"></div>
           <div className="flex flex-col items-end">
              <span className="text-[10px] uppercase opacity-30 tracking-[0.2em] font-black">Rata-rata Pasar</span>
              <span className="text-4xl font-display font-bold text-white italic">Rp 1.2jt</span>
           </div>
        </div>
      </div>

      {/* Collector's Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-10">
        {BEAN_DATA.map((bean, i) => (
          <motion.div
            key={bean.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1, duration: 0.6 }}
          >
            <Card className="group relative bg-[#121212] border border-white/5 rounded-[56px] overflow-hidden hover:bg-zinc-900 transition-all duration-700 hover:border-brand-gold/30 flex flex-col shadow-3xl">
               <div className="absolute top-10 right-10 z-20">
                  <Badge className="bg-brand-gold text-black border-none uppercase text-[9px] font-black tracking-widest px-4 py-2 rounded-full shadow-lg shadow-brand-gold/20">
                    {bean.rarity}
                  </Badge>
               </div>
               
               <CardContent className="p-12 space-y-10 flex-grow flex flex-col">
                  {/* Item Identifier */}
                  <div className="flex items-center gap-5">
                     <div className="text-[10px] font-black text-brand-gold/40 tracking-widest">SERI 0{i+1}</div>
                     <div className="w-full h-px bg-white/5" />
                  </div>

                  <div className="space-y-8">
                     <div className="space-y-2">
                        <div className="flex items-center gap-3">
                           <Globe className="w-4 h-4 text-brand-gold opacity-50" />
                           <span className="text-[10px] uppercase font-black tracking-[0.3em] text-white/20">{bean.country}</span>
                        </div>
                        <h3 className="text-5xl font-display leading-[0.8] tracking-tighter italic text-white group-hover:text-brand-gold transition-colors">{bean.name}</h3>
                     </div>

                     <div className="flex flex-wrap gap-2.5 pt-2">
                       {bean.flavorNotes.map(note => (
                         <span key={note} className="text-[9px] font-black px-5 py-2.5 rounded-full bg-white/[0.03] border border-white/10 text-white/30 uppercase tracking-tight group-hover:text-white transition-colors group-hover:border-white/20">
                           {note}
                         </span>
                       ))}
                     </div>
                  </div>

                  {/* Technical Specs */}
                  <div className="grid grid-cols-2 gap-x-12 gap-y-10 pt-10 border-t border-white/5">
                     <div className="space-y-2">
                        <span className="text-[9px] uppercase tracking-[0.2em] font-black text-white/20">KETINGGIAN ALAM</span>
                        <p className="text-sm font-bold italic text-white/60">{bean.altitude}</p>
                     </div>
                     <div className="space-y-2">
                        <span className="text-[9px] uppercase tracking-[0.2em] font-black text-white/20">METODE PROSES</span>
                        <p className="text-sm font-bold italic text-white/60">{bean.process}</p>
                     </div>
                     <div className="space-y-2">
                        <span className="text-[9px] uppercase tracking-[0.2em] font-black text-white/20">SKOR SENSORIK</span>
                        <div className="flex items-baseline gap-2">
                           <p className="text-3xl font-black italic text-brand-gold">{88 + bean.priceTier}.2</p>
                           <Activity className="w-4 h-4 text-brand-gold/40" />
                        </div>
                     </div>
                     <div className="space-y-2">
                        <span className="text-[9px] uppercase tracking-[0.2em] font-black text-white/20">INDEKS KELANGKAAN</span>
                        <div className="flex gap-1.5 mt-2">
                           {[...Array(5)].map((_, j) => (
                             <div key={j} className={`w-2 h-5 rounded-full transition-all duration-500 ${j < bean.priceTier ? 'bg-brand-gold shadow-[0_0_10px_rgba(212,175,55,0.4)]' : 'bg-white/5'}`} />
                           ))}
                        </div>
                     </div>
                  </div>

                  <button className="w-full h-16 rounded-[24px] bg-white/5 border border-white/10 mt-10 flex items-center justify-between px-10 hover:bg-brand-gold hover:border-transparent hover:text-black transition-all group overflow-hidden relative shadow-lg">
                    <span className="text-[10px] font-black tracking-[0.2em] uppercase">Periksa Detail Lot</span>
                    <ArrowUpRight className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                  </button>
               </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Information Panel */}
      <section className="bg-brand-sidebar rounded-[80px] border border-white/5 p-16 lg:p-32 relative overflow-hidden shadow-4xl">
         <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-brand-gold/5 blur-[160px] -mr-64 -mt-64 rounded-full pointer-events-none" />
         
         <div className="flex flex-col lg:flex-row gap-24 items-center relative z-10">
            <div className="w-full lg:w-[400px] aspect-square rounded-[64px] bg-white/[0.02] border border-white/5 flex items-center justify-center p-24 shadow-inner group">
               <ShieldCheck className="w-full h-full text-brand-gold opacity-40 group-hover:opacity-100 group-hover:scale-110 transition-all duration-1000" />
            </div>
            <div className="flex-grow space-y-12">
               <div className="space-y-6">
                  <h2 className="text-6xl md:text-7xl font-display italic leading-[0.9] text-white tracking-widest">Ambang <br /><span className="text-brand-gold">80-Poin</span></h2>
                  <p className="text-xl text-white/30 leading-relaxed max-w-2xl font-light">
                    Kopi spesialti bukan sekadar istilah pemasaran. Ini adalah pembedaan teknis untuk biji kopi hijau yang menunjukkan nol cacat utama dan skor luar biasa dalam wewangian, keasaman, dan keseragaman.
                  </p>
               </div>
               
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-12 pt-6">
                  {[
                    { title: "Ambang Batas Cacat", desc: "Benar-benar nol cacat utama per 350g sampel." },
                    { title: "Integritas Cupping", desc: "Berbagai evaluasi sensorik buta oleh Q-grader berlisensi." },
                    { title: "Keterlacakan Terroir", desc: "Koordinat tepat dari plot lahan dan lini waktu panen." },
                    { title: "Hasil Etis", desc: "Harga di atas pasar untuk perkebunan berkelanjutan." }
                  ].map((item, i) => (
                    <div key={i} className="space-y-3">
                       <h4 className="text-[12px] font-black text-brand-gold uppercase tracking-[0.3em]">{item.title}</h4>
                       <p className="text-base text-white/20 font-light leading-relaxed">{item.desc}</p>
                    </div>
                  ))}
               </div>
            </div>
         </div>
      </section>
    </div>
  );
}
