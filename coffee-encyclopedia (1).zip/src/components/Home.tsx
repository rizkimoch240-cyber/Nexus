
import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Star, TrendingUp, Award, Coffee, PenTool, Globe, Search, Zap, Clock, Thermometer, Plus, Map } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Link } from 'react-router-dom';
import { COFFEE_DATA, BEAN_DATA } from '@/data/coffees';
import { toast } from 'sonner';

export function Home() {
  const [preferences, setPreferences] = React.useState("");
  const [isRecommending, setIsRecommending] = React.useState(false);

  const handleRecommend = async () => {
    if (!preferences) return;
    setIsRecommending(true);
    try {
      const res = await fetch('/api/coffee/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ preferences })
      });
      const data = await res.json();
      toast.success(`Rekomendasi: ${data.name}`, {
        description: data.reason
      });
    } catch (e) {
      toast.error("Barista AI sedang sibuk. Coba lagi nanti.");
    } finally {
      setIsRecommending(false);
    }
  };

  return (
    <div className="space-y-12">
      {/* Featured Hero Card - Sleek Style */}
      <section className="relative h-[420px] rounded-[48px] bg-zinc-800 overflow-hidden group border border-white/5 shadow-2xl">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=1600" 
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000 grayscale brightness-75" 
            alt="Featured Roast"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/40 to-transparent" />
        </div>
        
        <div className="relative z-20 p-12 h-full flex flex-col justify-center max-w-2xl">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Badge className="bg-brand-gold text-black text-[10px] font-black mb-4 uppercase tracking-[0.2em] px-4 py-1.5 rounded-full border-none">
               Pilihan Pekan Ini
            </Badge>
            <h2 className="text-6xl md:text-7xl font-display font-medium mb-4 italic leading-[0.85] tracking-tighter text-white">
              Panama Geisha <br /> <span className="text-brand-gold">Hacienda Esmeralda</span>
            </h2>
            <p className="text-brand-cream/60 text-lg mb-10 max-w-lg leading-relaxed font-light">
              Rasakan aroma melati dengan sentuhan mandarin dan persik. Dikenal sebagai biji kopi yang paling dicari di dunia.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/coffee/panama-geisha">
                <Button className="bg-white text-black font-black text-[10px] uppercase tracking-widest px-8 h-12 rounded-xl border-none hover:bg-brand-gold transition-colors">
                  RESEP LENGKAP
                </Button>
              </Link>
              <Link to="/specialty">
                <Button variant="outline" className="border-white/20 text-white font-black text-[10px] uppercase tracking-widest px-8 h-12 rounded-xl backdrop-blur-md hover:bg-white hover:text-black transition-all">
                  CERITA ASAL
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        
        {/* Popular Types Section */}
        <div className="bg-zinc-900 border border-white/5 rounded-[48px] p-10 flex flex-col lg:h-[650px] shadow-3xl">
          <div className="flex justify-between items-center mb-10">
             <div className="space-y-1">
                <h3 className="text-[10px] font-black tracking-[0.2em] text-white/30 uppercase">Arsip Terpopuler</h3>
                <p className="text-xl font-display italic text-white">Menu Favorit</p>
             </div>
            <Link to="/encyclopedia" className="text-[10px] text-brand-gold font-bold tracking-widest border-b border-brand-gold/40 hover:border-brand-gold cursor-pointer transition-all uppercase">LIHAT SEMUA</Link>
          </div>
          
          <div className="space-y-5 overflow-y-auto pr-2 custom-scrollbar flex-grow">
            {COFFEE_DATA.slice(0, 6).map((coffee) => (
              <Link key={coffee.id} to={`/coffee/${coffee.id}`}>
                <div className="flex items-center gap-5 p-5 bg-white/[0.02] rounded-3xl border border-white/5 hover:border-brand-gold/30 hover:bg-brand-gold/5 transition-all cursor-pointer group">
                  <div className="w-16 h-16 rounded-2xl overflow-hidden bg-zinc-800 shrink-0 border border-white/5">
                    <img src={coffee.image} className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity grayscale group-hover:grayscale-0" alt={coffee.name} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-base font-bold text-white group-hover:text-brand-gold transition-colors">{coffee.name}</p>
                    <p className="text-[10px] text-white/30 truncate uppercase tracking-widest mt-1 font-black">{coffee.category} • {coffee.origin}</p>
                  </div>
                  <ArrowRight className="w-5 h-5 ml-auto opacity-0 group-hover:opacity-100 -translate-x-3 group-hover:translate-x-0 transition-all text-brand-gold" />
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Rare Beans Section */}
        <div className="bg-zinc-900 border border-white/5 rounded-[48px] p-10 lg:h-[650px] flex flex-col shadow-3xl">
          <div className="flex justify-between items-center mb-10">
             <div className="space-y-1">
                <h3 className="text-[10px] font-black tracking-[0.2em] text-white/30 uppercase">Pelacak Biji Langka</h3>
                <p className="text-xl font-display italic text-white">Stok Terbatas</p>
             </div>
            <Zap className="w-5 h-5 text-brand-gold animate-pulse" />
          </div>
          
          <div className="space-y-6 overflow-y-auto pr-2 custom-scrollbar flex-grow">
            {BEAN_DATA.slice(0, 4).map((bean) => (
              <div key={bean.id} className="relative p-6 rounded-3xl border border-white/5 bg-gradient-to-br from-white/[0.03] tracking-wide to-transparent group hover:border-brand-gold/30 transition-all">
                <p className="text-xs font-bold text-brand-gold mb-1 uppercase tracking-[0.2em]">{bean.name}</p>
                <p className="text-[10px] text-white/40 mb-6 font-black uppercase tracking-widest">{bean.country} • {bean.altitude}</p>
                <div className="flex flex-wrap gap-2">
                  {bean.flavorNotes.slice(0, 2).map((note) => (
                    <span key={note} className="text-[9px] font-black px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-white/30 uppercase tracking-tight group-hover:text-white transition-colors">{note}</span>
                  ))}
                  <Link to="/specialty" className="ml-auto w-8 h-8 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-brand-gold transition-colors group">
                    <Plus className="w-4 h-4 text-white/20 group-hover:text-black" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Brewing Dashboard / AI Section */}
        <div className="flex flex-col gap-12 lg:h-[650px]">
          {/* Quick Stats Panel */}
          <div className="bg-brand-gold rounded-[48px] p-10 text-black flex flex-col relative overflow-hidden group shadow-2xl shadow-brand-gold/20">
            <div className="absolute top-0 right-0 p-8 opacity-10 transform translate-x-4 -translate-y-4 group-hover:translate-x-2 group-hover:-translate-y-2 transition-transform duration-700">
               <Map className="w-32 h-32" />
            </div>
            <h3 className="text-[10px] font-black uppercase tracking-[0.3em] mb-10 opacity-40">Metrik Seduh Global</h3>
            
            <div className="bg-black/10 rounded-[32px] p-6 mb-8 backdrop-blur-md border border-black/5">
              <p className="text-[10px] font-black mb-2 opacity-40 uppercase tracking-widest text-center">RATA-RATA HASIL EKSTRAKSI</p>
              <div className="flex items-center justify-center gap-3">
                 <p className="text-5xl font-black italic tracking-tighter">20.4%</p>
                 <TrendingUp className="w-6 h-6" />
              </div>
              <p className="text-[10px] opacity-30 font-black mt-2 uppercase tracking-widest text-center italic">Target: 18-22%</p>
            </div>

            <div className="grid grid-cols-2 gap-5">
              <div className="bg-black/5 rounded-3xl p-5 flex flex-col border border-black/5 items-center">
                <p className="text-[9px] font-black opacity-40 uppercase tracking-widest mb-2">SUHU IDEAL</p>
                <p className="text-2xl font-black italic">92°C</p>
              </div>
              <div className="bg-black/5 rounded-3xl p-5 flex flex-col border border-black/5 items-center">
                <p className="text-[9px] font-black opacity-40 uppercase tracking-widest mb-2">RASIO EMAS</p>
                <p className="text-2xl font-black italic">1:16</p>
              </div>
            </div>
          </div>

          {/* AI Recommendation Mini-App */}
          <div className="bg-white/5 border border-white/10 rounded-[48px] p-10 flex-grow flex flex-col justify-center space-y-8 shadow-3xl">
             <div className="space-y-3">
                <div className="flex items-center gap-3">
                   <div className="w-2.5 h-2.5 rounded-full bg-brand-gold animate-pulse" />
                   <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-brand-gold">Asisten Barista AI</h3>
                </div>
                <p className="text-2xl font-display italic text-white leading-tight">"Apa profil rasa yang kamu inginkan hari ini?"</p>
             </div>
             
             <div className="space-y-4">
                <Input 
                   value={preferences}
                   onChange={(e) => setPreferences(e.target.value)}
                   placeholder="Cnth: Segar, buah, bersih..." 
                   className="rounded-2xl bg-white/5 border-white/10 h-12 text-sm placeholder:text-white/20 px-6"
                />
                <Button 
                   disabled={isRecommending || !preferences}
                   onClick={handleRecommend}
                   className="w-full rounded-2xl bg-white text-black font-black text-[11px] tracking-[0.2em] h-14 hover:bg-brand-gold transition-colors disabled:opacity-50 uppercase shadow-lg"
                >
                   {isRecommending ? 'MENGANALISIS...' : 'DAPATKAN REKOMENDASI'}
                </Button>
             </div>
          </div>
        </div>

      </div>

      {/* AI Visual Showcase Section */}
      <section className="pt-24 pb-12">
        <div className="bg-zinc-900 p-16 md:p-24 rounded-[64px] border border-white/5 flex flex-col md:flex-row items-center gap-24 relative overflow-hidden group shadow-4xl">
           <div className="absolute top-0 right-0 p-16 opacity-5 group-hover:opacity-10 transition-opacity">
              <Award className="w-80 h-80 text-brand-gold" />
           </div>
           <div className="w-full md:w-1/2 space-y-10 z-10">
              <div className="space-y-4">
                <div className="w-12 h-px bg-brand-gold" />
                <h2 className="text-6xl md:text-7xl font-display leading-[0.9] tracking-tighter italic text-white">Melampaui <br /><span className="text-brand-gold">Cangkir Standar</span></h2>
              </div>
              <p className="text-white/40 text-xl leading-relaxed font-light max-w-lg">
                 Ensiklopedia kami memanfaatkan neural indexing untuk melacak data sensorik dari 40+ wilayah asal, membantu Anda mengidentifikasi nuansa terroir dan metode pemrosesan yang belum pernah ada sebelumnya.
              </p>
              <div className="flex gap-16 pt-6">
                 <div className="space-y-2">
                    <p className="text-5xl font-display text-brand-gold italic">42rb+</p>
                    <p className="text-[10px] uppercase font-black tracking-[0.3em] text-white/20">Laporan Sensorik</p>
                 </div>
                 <div className="space-y-2">
                    <p className="text-5xl font-display text-brand-gold italic">99.2%</p>
                    <p className="text-[10px] uppercase font-black tracking-[0.3em] text-white/20">Akurasi Kecocokan</p>
                 </div>
              </div>
           </div>
           <div className="flex-grow flex gap-6 -rotate-6 z-10 translate-x-12 opacity-80 group-hover:opacity-100 transition-opacity duration-700">
              <div className="w-64 aspect-[3/4] rounded-[48px] bg-zinc-800 border border-white/10 overflow-hidden shadow-4xl">
                 <img src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=800" className="w-full h-full object-cover grayscale brightness-75" alt="Coffee 1" />
              </div>
              <div className="w-64 aspect-[3/4] rounded-[48px] bg-zinc-800 border border-white/10 overflow-hidden translate-y-24 shadow-4xl">
                 <img src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=800" className="w-full h-full object-cover grayscale brightness-75" alt="Coffee 2" />
              </div>
           </div>
        </div>
      </section>
    </div>
  );
}

// No fallback needed
