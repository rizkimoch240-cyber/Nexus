
import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Clock, Thermometer, Droplet, Coffee, ChefHat, Play, ChevronRight, Info, Book, Target, Ruler } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const BREWING_METHODS = [
  {
    id: "v60",
    name: "Hario V60",
    image: "https://images.unsplash.com/photo-1544787210-22c954d7ca8e?q=80&w=800",
    difficulty: "Mahir",
    ratio: "1:15",
    time: "3:00",
    temp: "92°C",
    description: "Instrumen presisi untuk biji kopi dengan tingkat keasaman tinggi. Sudut 60 derajat memastikan aliran optimal dan kejernihan sensorik.",
    steps: [
      "Persiapan: Lipat filter kertas dan pasang dengan rapat di dalam dripper keramik.",
      "Pemanasan: Bilas dengan air 94°C untuk menghilangkan sisa rasa kertas.",
      "Dosis: Masukkan 20.0g bubuk kopi gilingan medium-fine (800 mikron).",
      "Saturasi: Tuang 40g air (bloom), aduk perlahan, dan diamkan selama 35 detik.",
      "Aliran: Jaga tuangan lingkaran konsentris pada 5g/detik hingga total hasil 300g.",
      "Selesai: Agitasi vertikal pada 2:30. Pemisahan akhir tepat pada 3:00."
    ]
  },
  {
    id: "aeropress",
    name: "AeroPress",
    image: "https://images.unsplash.com/photo-1518832553480-cd0e625ed3e6?q=80&w=800",
    difficulty: "Menengah",
    ratio: "1:11",
    time: "2:00",
    temp: "85°C",
    description: "Sistem perendaman pneumatik. Dikenal dengan ekstraksi yang ditingkatkan tekanan dan portabilitas total.",
    steps: [
      "Siapkan: Pasang filter kertas ganda untuk penyaringan partikel maksimal.",
      "Inversi: Gunakan metode terbalik (inverted) untuk kontrol perendaman penuh.",
      "Dosis: 18g bubuk kopi gilingan medium-to-halus.",
      "Infusi: Tuangkan 200g air 85°C dengan cepat dan aduk selama 10 detik.",
      "Rendam: Tutup ruang udara dan biarkan kontak statis selama 90 detik.",
      "Tekan: Tekanan pneumatik stabil selama 30 detik melalui tabung."
    ]
  },
  {
    id: "french-press",
    name: "French Press",
    image: "https://images.unsplash.com/photo-1542385151-efd9271a2f64?q=80&w=800",
    difficulty: "Pemula",
    ratio: "1:15",
    time: "4:00",
    temp: "96°C",
    description: "Metode seduh imersi klasik menggunakan filtrasi jaring logam untuk retensi lipid tinggi dan body yang tegas.",
    steps: [
      "Masukkan: 30g kopi gilingan kasar (1200+ mikron) ke dalam carafe panas.",
      "Bloom: Saturasi penuh bubuk kopi dengan 450g air panas.",
      "Ekstraksi: Biarkan terendam statis selama 4 menit. Jangan ganggu lapisan atas.",
      "Bersihkan: Gunakan sendok untuk membuang busa atas dan ampas mengapung (metode Hofmann).",
      "Endapkan: Biarkan selama 5 menit untuk pengendapan gravitasi setelah plunger dipasang.",
      "Sajikan: Tuang perlahan untuk menjaga kejernihan hasil seduhan."
    ]
  }
];

export function BrewingGuide() {
  const [selectedMethod, setSelectedMethod] = React.useState(BREWING_METHODS[0]);

  return (
    <div className="space-y-16">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
        <div className="space-y-2">
          <Badge className="bg-brand-gold/10 text-brand-gold border-brand-gold/20 uppercase tracking-[0.2em] text-[10px] px-3 py-1 mb-2">
            Manual Pedagogis
          </Badge>
          <h1 className="text-6xl font-display font-medium tracking-tight italic leading-tight text-white italic">
            Atlas <span className="text-brand-gold">Ekstraksi</span>
          </h1>
          <p className="text-white/40 max-w-lg font-light leading-relaxed">
            Instruksi kanonikal untuk persiapan kopi spesialti. Ikuti parameter secara presisi untuk membuka potensi terpendam dari biji kopi Anda.
          </p>
        </div>
        
        <div className="flex bg-white/5 p-1.5 rounded-[20px] border border-white/10 shadow-xl">
           {BREWING_METHODS.map((m) => (
              <button 
                key={m.id}
                onClick={() => setSelectedMethod(m)}
                className={`px-8 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                  selectedMethod.id === m.id ? 'bg-brand-gold text-black shadow-lg shadow-brand-gold/20' : 'text-white/20 hover:text-white'
                }`}
              >
                {m.name}
              </button>
           ))}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-12 pt-4">
        {/* Visual Documentation Panel */}
        <div className="xl:col-span-12">
           <AnimatePresence mode="wait">
              <motion.div
                key={selectedMethod.id}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.6 }}
                className="bg-zinc-900 border border-white/5 rounded-[64px] overflow-hidden flex flex-col lg:flex-row shadow-4xl"
              >
                 {/* Hero Image Section */}
                 <div className="lg:w-2/5 aspect-[4/5] lg:aspect-auto overflow-hidden relative group">
                    <img src={selectedMethod.image} className="w-full h-full object-cover grayscale brightness-50 group-hover:grayscale-0 group-hover:brightness-100 transition-all duration-[2s]" alt={selectedMethod.name} />
                    <div className="absolute inset-x-0 bottom-0 p-12 bg-gradient-to-t from-black via-black/40 to-transparent">
                       <h2 className="text-7xl font-display italic text-white mb-2 leading-none tracking-tighter">{selectedMethod.name}</h2>
                       <Badge className="bg-brand-gold text-black uppercase font-black text-[9px] tracking-[0.3em] px-4 py-2">{selectedMethod.difficulty}</Badge>
                    </div>
                 </div>

                 {/* Technical Protocol Section */}
                 <div className="lg:w-3/5 p-12 lg:p-24 space-y-16">
                    <div className="space-y-6">
                       <div className="flex items-center gap-3">
                          <Book className="w-4 h-4 text-brand-gold/60" />
                          <span className="text-[10px] uppercase font-black tracking-[0.4em] text-white/20 italic">Abstrak Protokol</span>
                       </div>
                       <p className="text-3xl text-white font-light leading-relaxed max-w-xl italic">
                         {selectedMethod.description}
                       </p>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-12 pt-4">
                       {[
                         { icon: Ruler, label: "Rasio", value: selectedMethod.ratio },
                         { icon: Clock, label: "Waktu", value: selectedMethod.time },
                         { icon: Thermometer, label: "Suhu", value: selectedMethod.temp },
                         { icon: Target, label: "Keseragaman", value: "85%" }
                       ].map((spec, i) => (
                         <div key={i} className="space-y-2">
                            <spec.icon className="w-5 h-5 text-brand-gold/40 mb-3" />
                            <p className="text-[9px] uppercase tracking-[0.2em] font-black text-white/10 whitespace-nowrap">{spec.label}</p>
                            <p className="text-2xl font-black italic text-white tracking-widest">{spec.value}</p>
                         </div>
                       ))}
                    </div>

                    <div className="space-y-12">
                       <div className="flex items-center justify-between border-b border-white/5 pb-6">
                          <div className="flex items-center gap-3">
                             <ChefHat className="w-5 h-5 text-brand-gold/60" />
                             <h3 className="text-[10px] uppercase tracking-[0.4em] font-black text-white/20">Prosedur Langkah demi Langkah</h3>
                          </div>
                          <Button variant="ghost" size="sm" className="text-[9px] uppercase font-black text-brand-gold hover:text-white tracking-widest">
                             <Play className="w-3 h-3 mr-2" /> Tonton Video Lab
                          </Button>
                       </div>
                       
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-x-20 gap-y-12">
                          {selectedMethod.steps.map((step, i) => (
                            <div key={i} className="flex gap-8 group">
                               <div className="text-5xl font-display italic text-white/5 group-hover:text-brand-gold transition-all duration-700 shrink-0 select-none">
                                 {String(i + 1).padStart(2, '0')}
                               </div>
                               <p className="text-base text-white/30 group-hover:text-white/70 transition-colors leading-relaxed font-light">
                                  {step}
                               </p>
                            </div>
                          ))}
                       </div>
                    </div>

                    <div className="p-10 bg-black/40 rounded-[48px] border border-white/5 flex flex-col md:flex-row items-center justify-between gap-8 shadow-inner">
                       <div className="flex items-center gap-8">
                          <div className="w-14 h-14 rounded-full bg-brand-gold/5 flex items-center justify-center border border-brand-gold/10">
                             <Info className="w-6 h-6 text-brand-gold/40" />
                          </div>
                          <div className="space-y-2">
                             <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-white/30">Heuristik Pakar</h4>
                             <p className="text-sm text-white/20 italic font-light max-w-sm leading-snug">"Selalu timbang air Anda hingga satuan desigram. Pengukuran volumetrik adalah musuh konsistensi."</p>
                          </div>
                       </div>
                       <Button className="rounded-2xl bg-white text-black font-black text-[10px] uppercase tracking-[0.3em] h-14 px-10 hover:bg-brand-gold transition-all shadow-xl hover:scale-105 active:scale-95">
                          MULAI TIMER
                       </Button>
                    </div>
                 </div>
              </motion.div>
           </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
