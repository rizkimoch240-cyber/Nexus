
import React from 'react';
import { motion } from 'motion/react';
import { Calculator, Clock, Thermometer, Droplet, Coffee, Save, History, Scale, TrendingUp, Info, Zap, Sliders, Activity, RefreshCcw } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';

export function BaristaMode() {
  const [coffeeWeight, setCoffeeWeight] = React.useState(18);
  const [ratio, setRatio] = React.useState(16);
  const [waterWeight, setWaterWeight] = React.useState(288);
  
  const [timerSeconds, setTimerSeconds] = React.useState(0);
  const [isTimerRunning, setIsTimerRunning] = React.useState(false);
  const timerRef = React.useRef<any>(null);

  React.useEffect(() => {
    if (isTimerRunning) {
      timerRef.current = setInterval(() => {
        setTimerSeconds(s => s + 1);
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [isTimerRunning]);

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCoffeeChange = (val: number) => {
    setCoffeeWeight(val);
    setWaterWeight(val * ratio);
  };

  const handleRatioChange = (val: number) => {
    setRatio(val);
    setWaterWeight(coffeeWeight * val);
  };

  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-end gap-8">
        <div className="space-y-4">
           <Badge className="bg-brand-gold/10 text-brand-gold border-brand-gold/20 uppercase tracking-[0.3em] text-[10px] px-4 py-1.5 mb-2 font-black">
             Presisi Teknis
           </Badge>
           <h1 className="text-7xl md:text-8xl font-display font-medium tracking-tight italic leading-[0.8] text-white italic">
             Stasiun <span className="text-brand-gold">Barista</span>
           </h1>
           <p className="text-white/30 max-w-lg font-light leading-relaxed text-lg">
             Sesuaikan variabel seduhan Anda dengan akurasi tingkat laboratorium. Pantau laju aliran, hasil ekstraksi, dan rasio spesifik biji kopi.
           </p>
        </div>
        
        <div className="flex gap-5">
           <div title="Reset All" className="w-14 h-14 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center text-brand-gold hover:bg-brand-gold hover:text-black transition-all cursor-pointer shadow-xl">
              <RefreshCcw className="w-6 h-6" />
           </div>
           <div title="View History" className="w-14 h-14 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center text-white/30 hover:text-white transition-all cursor-pointer shadow-xl">
              <History className="w-6 h-6" />
           </div>
        </div>
      </div>

      <Tabs defaultValue="calculator" className="w-full">
        <TabsList className="bg-white/5 p-2 rounded-[32px] h-[72px] w-full md:w-auto mb-12 border border-white/5 shadow-2xl">
          <TabsTrigger value="calculator" className="rounded-[24px] px-10 h-full data-[state=active]:bg-brand-gold data-[state=active]:text-black uppercase text-[11px] font-black tracking-[0.2em] transition-all">Metrik Seduh</TabsTrigger>
          <TabsTrigger value="extraction" className="rounded-[24px] px-10 h-full data-[state=active]:bg-brand-gold data-[state=active]:text-black uppercase text-[11px] font-black tracking-[0.2em] transition-all">Monitor Aliran</TabsTrigger>
          <TabsTrigger value="journal" className="rounded-[24px] px-10 h-full data-[state=active]:bg-brand-gold data-[state=active]:text-black uppercase text-[11px] font-black tracking-[0.2em] transition-all">Jurnal Sensorik</TabsTrigger>
        </TabsList>

        <TabsContent value="calculator" className="mt-0">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
             <Card className="bg-zinc-900 border border-white/5 rounded-[64px] p-16 space-y-16 shadow-4xl relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-80 h-80 bg-brand-gold/5 blur-[100px] -mr-32 -mt-32 rounded-full" />
                <div className="space-y-12 relative z-10">
                   <div className="space-y-8">
                      <div className="flex justify-between items-center px-4">
                         <Label className="text-[11px] uppercase tracking-[0.3em] font-black text-white/20">Dosis Input</Label>
                         <span className="text-5xl font-display italic text-brand-gold tracking-widest">{coffeeWeight.toFixed(1)}<span className="text-lg ml-2 opacity-30 font-black">GR</span></span>
                      </div>
                      <div className="px-4">
                        <Slider 
                          value={[coffeeWeight]} 
                          max={100} 
                          min={1}
                          step={0.1} 
                          onValueChange={(v) => handleCoffeeChange(v[0])} 
                          className="cursor-pointer"
                        />
                      </div>
                   </div>

                   <div className="space-y-8">
                      <div className="flex justify-between items-center px-4">
                         <Label className="text-[11px] uppercase tracking-[0.3em] font-black text-white/20">Rasio Target</Label>
                         <span className="text-5xl font-display italic text-brand-gold tracking-widest">1:{ratio.toFixed(1)}</span>
                      </div>
                      <div className="px-4">
                        <Slider 
                          value={[ratio]} 
                          min={2} 
                          max={40} 
                          step={0.1} 
                          onValueChange={(v) => handleRatioChange(v[0])} 
                          className="cursor-pointer"
                        />
                      </div>
                   </div>
                </div>

                <div className="p-12 bg-brand-gold rounded-[48px] flex flex-col items-center justify-center space-y-3 group overflow-hidden relative shadow-2xl shadow-brand-gold/20 hover:scale-[1.02] transition-transform">
                   <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                   <div className="w-16 h-1 w-white/20 rounded-full mb-2 opacity-30" />
                   <span className="text-[11px] font-black uppercase tracking-[0.5em] text-black/40 relative z-10">Hasil Kalkulasi (Yield)</span>
                   <div className="text-8xl font-display font-medium text-black italic relative z-10 tracking-tighter">{waterWeight.toFixed(1)}<span className="text-2xl ml-2 font-black opacity-30">ML</span></div>
                   <div className="w-16 h-1 bg-black/10 rounded-full mt-6 relative z-10" />
                </div>
             </Card>
             
             <div className="space-y-10">
                <div className="p-12 bg-white/5 rounded-[56px] border border-white/10 space-y-10 shadow-3xl">
                   <div className="flex items-center gap-4">
                     <Activity className="w-5 h-5 text-brand-gold/60" />
                     <h3 className="text-[11px] uppercase tracking-[0.4em] font-black text-white/30 italic">Preset Ekstraksi</h3>
                   </div>
                   <div className="grid grid-cols-2 gap-6">
                      {[
                        { name: "S. O. Espresso", ratio: "1:2.5" },
                        { name: "Modern Filter", ratio: "1:16.6" },
                        { name: "Immersion", ratio: "1:14.0" },
                        { name: "Japanese Iced", ratio: "1:10.0" },
                      ].map(r => (
                        <button 
                          key={r.name} 
                          onClick={() => handleRatioChange(parseFloat(r.ratio.split(":")[1]))}
                          className="flex flex-col items-start p-8 rounded-[36px] bg-white/[0.03] border border-white/5 hover:border-brand-gold/40 hover:bg-brand-gold/5 transition-all text-left group shadow-lg"
                        >
                          <span className="text-[10px] font-black text-white/20 uppercase tracking-[0.2em] mb-2 group-hover:text-brand-gold transition-colors">{r.name}</span>
                          <span className="text-3xl font-display italic text-white group-hover:text-brand-gold transition-colors italic">{r.ratio}</span>
                        </button>
                      ))}
                   </div>
                </div>
                
                <div className="p-12 rounded-[56px] bg-brand-sidebar border border-white/5 space-y-8 shadow-4xl relative overflow-hidden">
                   <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/5 blur-[80px] -mr-24 -mt-24 rounded-full" />
                   <div className="flex items-center gap-6 relative z-10">
                      <div className="w-14 h-14 rounded-2xl bg-brand-gold/5 flex items-center justify-center text-brand-gold border border-brand-gold/10">
                         <Calculator className="w-7 h-7 opacity-60" />
                      </div>
                      <div className="space-y-1">
                        <h3 className="font-display text-3xl italic text-white leading-none">Puncak Sensorik</h3>
                        <p className="text-[10px] uppercase font-black text-white/20 tracking-[0.3em]">Konsensus Aero-Logika</p>
                      </div>
                   </div>
                   <p className="text-white/30 text-base leading-relaxed font-light relative z-10 tracking-tight">
                     Sebagian besar lot Geisha sangrai ringan (light roast) mencapai kompleksitas puncak pada rasio 1:16.63 menggunakan air mineral lunak bersuhu 94°C.
                   </p>
                </div>
             </div>
          </div>
        </TabsContent>

        <TabsContent value="extraction" className="mt-0">
           <div className="max-w-4xl mx-auto flex flex-col items-center space-y-20 py-16">
              <div className="relative w-[450px] h-[450px] rounded-full border border-white/5 flex flex-col items-center justify-center bg-black/40 shadow-inner group overflow-hidden">
                 <div className="absolute inset-0 bg-gradient-to-b from-brand-gold/5 to-transparent opacity-20 pointer-events-none" />
                 
                 {/* Visual Flow Animation */}
                 <div className={`absolute inset-0 rounded-full border-[12px] border-brand-gold/10 border-t-brand-gold ${isTimerRunning ? 'animate-[spin_4s_linear_infinite]' : ''}`} />
                 
                 <div className="absolute top-16 text-[11px] uppercase font-black tracking-[0.6em] text-white/20 italic">Chrono Ekstraksi</div>
                 <div className="text-[10rem] font-display font-medium text-brand-gold italic tabular-nums leading-none tracking-tighter drop-shadow-[0_0_50px_rgba(212,175,55,0.2)]">{formatTime(timerSeconds)}</div>
                 
                 <div className="absolute bottom-20 flex gap-6 z-10">
                    <Button 
                      onClick={() => setIsTimerRunning(!isTimerRunning)} 
                      className={`rounded-full h-20 px-16 font-black text-[12px] tracking-[0.3em] uppercase transition-all shadow-4xl border-none italic ${isTimerRunning ? 'bg-red-500/80 hover:bg-red-500 text-white' : 'bg-white hover:bg-brand-gold text-black'}`}
                    >
                      {isTimerRunning ? 'JEDA ALIRAN' : 'MULAI SEDUH'}
                    </Button>
                    <Button onClick={() => { setTimerSeconds(0); setIsTimerRunning(false); }} variant="outline" className="w-20 h-20 p-0 rounded-full border-white/10 glass hover:bg-white/10 hover:border-brand-gold transition-all group">
                       <RefreshCcw className="w-7 h-7 opacity-40 group-hover:opacity-100 transition-opacity" />
                    </Button>
                 </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 w-full gap-10">
                 {[
                   { label: 'Degassing CO2', target: '00:35', desc: 'Fase Pra-infusi (Bloom)' },
                   { label: 'Ekstrak Puncak', target: '02:30', desc: 'Maksimum Cita Rasa' },
                   { label: 'Pembersihan', target: '03:15', desc: 'Titik Henti Seduh' },
                 ].map(mark => (
                   <div key={mark.label} className="bg-zinc-900 p-10 rounded-[48px] border border-white/5 space-y-3 text-center group hover:border-brand-gold/30 transition-all shadow-2xl">
                      <div className="text-[10px] uppercase tracking-[0.4em] font-black text-white/20 group-hover:text-brand-gold transition-colors italic">{mark.label}</div>
                      <div className="text-4xl font-display italic text-white leading-none tracking-widest">{mark.target}</div>
                      <p className="text-[11px] font-black text-white/10 uppercase tracking-tighter group-hover:text-white/30 transition-colors pt-2">{mark.desc}</p>
                   </div>
                 ))}
              </div>
           </div>
        </TabsContent>

        <TabsContent value="journal" className="mt-0">
           <div className="text-center py-40 bg-zinc-900 rounded-[80px] border border-white/5 space-y-10 flex flex-col items-center shadow-4xl relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-brand-gold/5 via-transparent to-transparent opacity-40" />
              <div className="w-32 h-32 rounded-[56px] bg-white/[0.02] border border-white/10 flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform duration-1000">
                 <History className="w-14 h-14 text-white/10 group-hover:text-brand-gold transition-colors duration-1000" />
              </div>
              <div className="space-y-6 relative z-10">
                 <h2 className="text-6xl font-display italic leading-[0.9] text-white">Brankas Digital <br /><span className="text-brand-gold font-bold">Terkunci</span></h2>
                 <p className="text-white/20 max-w-md mx-auto font-light leading-relaxed text-lg tracking-tight">
                   Sinkronkan profil Anda untuk menyimpan catatan permanen dari setiap cangkir, catatan sensorik, dan rasio kustom yang Anda jelajahi.
                 </p>
              </div>
              <Button className="rounded-[32px] bg-white text-black hover:bg-brand-gold font-black text-[11px] tracking-[0.4em] h-20 px-20 transition-all shadow-4xl shadow-black relative z-10 italic uppercase group-hover:scale-105 active:scale-95">
                INISIASI SINKRONISASI
              </Button>
           </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
