
import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Coffee, Search, Book, PenTool, Heart, Menu, X, Globe, Map, Layout as LayoutIcon, User, Layers, Sliders } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';

const DISCOVERY_LINKS = [
  { label: 'Beranda', path: '/', icon: Coffee },
  { label: 'Ensiklopedia Dunia', path: '/encyclopedia', icon: Globe },
  { label: 'Biji Spesialti', path: '/specialty', icon: Layers },
];

const EDUCATION_LINKS = [
  { label: 'Panduan Seduh', path: '/brewing', icon: Book },
  { label: 'Sekolah Barista', path: '/barista', icon: PenTool },
];

const TOOL_LINKS = [
  { label: 'Kalkulator Rasio', path: '/barista', icon: Sliders },
  { label: 'Jurnal Rasa', path: '/barista', icon: LayoutIcon },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();

  return (
    <div className="flex min-h-screen bg-brand-dark text-brand-cream font-sans overflow-hidden">
      {/* Sidebar Navigation - Hidden on mobile, visible on medium+ */}
      <aside className="hidden md:flex w-72 bg-brand-sidebar border-r border-white/5 flex-col shrink-0">
        <div className="p-10">
          <Link to="/" className="flex items-center gap-3 mb-12">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand-gold to-brand-gold-muted flex items-center justify-center shadow-lg transform group-hover:rotate-12 transition-all">
              <Coffee className="w-6 h-6 text-black" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-brand-gold">KEDAI ENCY</h1>
          </Link>

          <nav className="space-y-10">
            <NavGroup title="Penjelajahan" items={DISCOVERY_LINKS} currentPath={location.pathname} />
            <NavGroup title="Edukasi" items={EDUCATION_LINKS} currentPath={location.pathname} />
            <NavGroup title="Peralatan" items={TOOL_LINKS} currentPath={location.pathname} />
          </nav>
        </div>

        <div className="mt-auto p-8 border-t border-white/5">
          <div className="flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-brand-gold/40 cursor-pointer transition-all">
            <div className="w-9 h-9 rounded-full bg-zinc-700 overflow-hidden flex items-center justify-center bg-brand-gold/20">
               <User className="w-5 h-5 text-brand-gold" />
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-bold truncate">Master Barista</p>
              <p className="text-[10px] text-white/40 uppercase tracking-widest">Lihat Portofolio</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Viewport */}
      <main className="flex-1 flex flex-col relative min-w-0 h-screen">
        {/* Top Header */}
        <header className="h-20 flex items-center justify-between px-6 md:px-10 border-b border-white/5 bg-brand-dark/80 backdrop-blur-md z-30">
          <div className="flex items-center gap-4">
             {/* Mobile Menu Trigger */}
             <div className="md:hidden">
                <Sheet>
                  <SheetTrigger render={<Button variant="ghost" size="icon" className="hover:bg-white/10" />}>
                    <Menu className="w-6 h-6" />
                  </SheetTrigger>
                  <SheetContent side="left" className="bg-brand-sidebar border-white/5 text-white p-0 w-72">
                     <div className="p-8 space-y-10">
                        <Link to="/" className="flex items-center gap-3 mb-10">
                          <Coffee className="w-6 h-6 text-brand-gold" />
                          <h1 className="text-xl font-bold tracking-tight text-brand-gold">KEDAI ENCY</h1>
                        </Link>
                        <nav className="space-y-8 text-left">
                          <NavGroup title="Penjelajahan" items={DISCOVERY_LINKS} currentPath={location.pathname} />
                          <NavGroup title="Edukasi" items={EDUCATION_LINKS} currentPath={location.pathname} />
                          <NavGroup title="Peralatan" items={TOOL_LINKS} currentPath={location.pathname} />
                        </nav>
                     </div>
                  </SheetContent>
                </Sheet>
             </div>
             
             <div className="relative w-full max-w-sm hidden sm:block">
               <input 
                 type="text" 
                 placeholder="Cari asal, rasa, atau metode seduh..." 
                 className="w-full bg-white/5 border border-white/10 rounded-full py-2.5 px-12 text-sm focus:outline-none focus:border-brand-gold/50 transition-all font-light text-white"
               />
               <Search className="absolute left-4 top-2.5 w-5 h-5 text-white/20" />
             </div>
          </div>

          <div className="flex items-center gap-4 md:gap-8">
            <div className="hidden lg:flex flex-col items-end">
              <span className="text-[10px] text-white/40 uppercase tracking-widest font-semibold">Indeks Spesialti Global</span>
              <span className="text-lg font-bold text-brand-gold">94.8 SCA</span>
            </div>
            <div className="w-px h-10 bg-white/10 hidden lg:block"></div>
            <Button className="bg-brand-gold text-black font-bold text-xs px-6 py-2.5 rounded-full hover:brightness-110 shadow-lg shadow-brand-gold/20 border-none h-10">
              JELAJAHI PETA
            </Button>
          </div>
        </header>

        {/* Content Area */}
        <section className="flex-1 overflow-y-auto custom-scrollbar relative z-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
              className="p-6 md:p-10 pb-24"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </section>

        {/* Background Texture Decoration */}
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-brand-gold/5 rounded-full blur-[140px] -mr-48 -mb-48 pointer-events-none -z-0"></div>
      </main>
    </div>
  );
}

function NavGroup({ title, items, currentPath }: { title: string, items: any[], currentPath: string }) {
  return (
    <div className="space-y-4">
      <p className="text-[10px] uppercase tracking-[0.2em] text-white/30 font-bold px-1">{title}</p>
      <div className="space-y-1">
        {items.map((item) => (
          <Link
            key={item.label}
            to={item.path}
            className={`flex items-center gap-4 text-sm py-2 px-1 transition-all group ${
              currentPath === item.path ? 'text-brand-gold font-medium' : 'text-white/40 hover:text-white'
            }`}
          >
            <div className={`w-1.5 h-1.5 rounded-full transition-all ${
              currentPath === item.path ? 'bg-brand-gold scale-100' : 'bg-transparent scale-0 group-hover:scale-75 group-hover:bg-brand-gold/50'
            }`} />
            <item.icon className={`w-4 h-4 ${currentPath === item.path ? 'text-brand-gold' : 'opacity-50'}`} />
            {item.label}
          </Link>
        ))}
      </div>
    </div>
  );
}
