/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './components/Home';
import { Encyclopedia } from './components/Encyclopedia';
import { CoffeeDetail } from './components/CoffeeDetail';
import { BrewingGuide } from './components/BrewingGuide';
import { SpecialtyBeans } from './components/SpecialtyBeans';
import { BaristaMode } from './components/BaristaMode';
import { Toaster } from '@/components/ui/sonner';

export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/encyclopedia" element={<Encyclopedia />} />
          <Route path="/coffee/:id" element={<CoffeeDetail />} />
          <Route path="/brewing" element={<BrewingGuide />} />
          <Route path="/specialty" element={<SpecialtyBeans />} />
          <Route path="/barista" element={<BaristaMode />} />
        </Routes>
      </Layout>
      <Toaster position="top-right" theme="dark" closeButton />
    </Router>
  );
}
