import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Sidebar } from './components/layout/Sidebar';
import { LandingPage } from './pages/LandingPage';
import { LessonViewer } from './pages/LessonViewer';
import { motion, AnimatePresence } from 'motion/react';
import { Map, Zap, BarChart2 } from 'lucide-react';
import { SkillTree } from './components/curriculum/SkillTree';

import { AnalyticsPage } from './pages/AnalyticsPage';
import { CommandPalette } from './components/ui/CommandPalette';
import { AchievementToast } from './components/ui/AchievementToast';
import { useStore } from './store/useStore';

// Placeholder Pages
const CurriculumDashboard = () => (
  <div className="p-8 max-w-7xl mx-auto space-y-8">
    <header className="flex justify-between items-end">
      <div>
        <h1 className="text-5xl font-display mb-2 text-gradient-cyan">MATHEMATICS TREE</h1>
        <p className="text-text-secondary">Visualize your path from basic arithmetic to research-level topology.</p>
      </div>
      <div className="glass px-6 py-4 rounded-2xl flex items-center gap-8">
        <div className="text-center">
          <div className="text-2xl font-display font-bold">12%</div>
          <div className="text-[10px] font-mono text-text-secondary uppercase">Discovery Rate</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-display font-bold">428</div>
          <div className="text-[10px] font-mono text-text-secondary uppercase">Stars Earned</div>
        </div>
      </div>
    </header>
    
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
      <div className="lg:col-span-3">
        <SkillTree className="h-[600px]" onNodeClick={(id) => console.log('Node clicked:', id)} />
      </div>
      <div className="space-y-6">
        <div className="glass p-6 rounded-2xl border-accent-cyan/20">
          <h3 className="text-sm font-bold uppercase tracking-wider mb-4 flex items-center gap-2">
            <Zap size={14} className="text-accent-cyan" /> Next Milestone
          </h3>
          <div className="p-4 bg-white/5 rounded-xl mb-4">
            <div className="text-xs font-mono text-accent-cyan mb-1">LEVEL 3 — UNIVERSITY CORE</div>
            <div className="font-bold mb-2">Calculus I: Limits & Continuity</div>
            <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
              <div className="h-full w-2/3 bg-accent-cyan" />
            </div>
          </div>
          <button className="w-full py-3 bg-accent-cyan text-black font-bold rounded-xl text-sm">RESUME JOURNEY</button>
        </div>

        <div className="glass p-6 rounded-2xl">
          <h3 className="text-sm font-bold uppercase tracking-wider mb-4">Mastery Radar</h3>
          {/* Radar chart placeholder */}
          <div className="aspect-square rounded-full border-2 border-white/5 flex items-center justify-center relative">
            <div className="absolute inset-4 rounded-full border border-white/10" />
            <div className="absolute inset-8 rounded-full border border-white/10" />
            <BarChart2 className="text-white/20" size={32} />
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default function App() {
  const [showToast, setShowToast] = React.useState(false);

  // Trigger achievement after a delay for demo
  React.useEffect(() => {
    const timer = setTimeout(() => setShowToast(true), 10000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="flex min-h-screen bg-bg-primary text-text-primary">
      <CommandPalette />
      <AnimatePresence>
        {showToast && (
          <AchievementToast
            id="first-mastery"
            title="THE INITIATE"
            description="Reached Level 3 in the Mathematics curriculum."
            onClose={() => setShowToast(false)}
          />
        )}
      </AnimatePresence>
      <Sidebar />
      <div className="flex-1 relative">
        <AnimatePresence mode="wait">
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/curriculum" element={<CurriculumDashboard />} />
            <Route path="/curriculum/:subjectId" element={<CurriculumDashboard />} />
            <Route path="/lessons" element={<LessonViewer />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </AnimatePresence>
      </div>
    </div>
  );
}
