import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type Level = 0 | 1 | 2 | 3 | 4 | 5 | 6;

export interface UserProgress {
  xp: number;
  completedLessons: string[];
  mastery: Record<string, number>; // topicId -> percentage
  streak: number;
  lastActive: string;
}

interface AppState {
  user: UserProgress;
  addXP: (amount: number) => void;
  completeLesson: (lessonId: string) => void;
  updateMastery: (topicId: string, percentage: number) => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      user: {
        xp: 1250,
        completedLessons: [],
        mastery: {},
        streak: 5,
        lastActive: new Date().toISOString(),
      },
      addXP: (amount) => set((state) => ({ 
        user: { ...state.user, xp: state.user.xp + amount } 
      })),
      completeLesson: (lessonId) => set((state) => ({
        user: { 
          ...state.user, 
          completedLessons: [...state.user.completedLessons, lessonId] 
        }
      })),
      updateMastery: (topicId, percentage) => set((state) => ({
        user: {
          ...state.user,
          mastery: { ...state.user.mastery, [topicId]: percentage }
        }
      })),
    }),
    { name: 'nexus-storage' }
  )
);
