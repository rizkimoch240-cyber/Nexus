import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  CheckCircle, 
  HelpCircle, 
  MessageSquare,
  Clock,
  BarChart,
  Trophy,
  History,
  Info,
  Lightbulb,
  ExternalLink,
  Code
} from 'lucide-react';
import { MathFormula } from '@/src/components/ui/MathFormula';
import { ContentBox } from '@/src/components/ui/ContentBox';
import { ProgressRing } from '@/src/components/ui/ProgressRing';
import { HintBox } from '@/src/components/ui/HintBox';
import Editor from '@monaco-editor/react';
import { cn } from '@/src/lib/utils';

export const LessonViewer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'content' | 'interactive'>('content');
  const [section, setSection] = useState(0);
  
  const sections = [
    { title: "Introduction", status: "completed" },
    { title: "The Intuition", status: "current" },
    { title: "Formal Definition", status: "locked" },
    { title: "Numerical Demo", status: "locked" },
    { title: "Research Frontier", status: "locked" },
  ];

  return (
    <div className="flex h-[calc(100vh-0px)] overflow-hidden">
      {/* Table of Contents / Progress */}
      <aside className="w-16 flex flex-col items-center py-8 border-r border-border bg-bg-secondary gap-6">
        {sections.map((s, i) => (
          <button 
            key={i} 
            onClick={() => setSection(i)}
            className="relative group"
          >
            <div className={cn(
              "w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-300",
              section === i ? "bg-accent-cyan text-black" : "bg-white/5 text-text-secondary hover:bg-white/10"
            )}>
              {s.status === 'completed' ? <CheckCircle size={18} /> : <span>{i + 1}</span>}
            </div>
            <div className="absolute left-16 px-3 py-1.5 bg-text-primary text-black text-xs font-bold rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50">
              {s.title}
            </div>
          </button>
        ))}
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="h-16 px-8 border-b border-border flex items-center justify-between glass">
          <div className="flex items-center gap-4">
            <span className="text-xs font-mono text-accent-cyan">CALCULUS I — CHAPTER 4.2</span>
            <h1 className="text-lg font-bold">The Derivative: Instantaneous Change</h1>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-xs font-mono text-text-secondary">
              <Clock size={14} /> 12 MIN READ
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-text-secondary">
              <BarChart size={14} /> DIFFICULTY: 4/10
            </div>
            <button className="px-4 py-1.5 bg-accent-violet rounded-lg text-xs font-bold text-white shadow-lg shadow-accent-violet/20">
              SUBMIT PROGRESS
            </button>
          </div>
        </header>

        {/* Scrolling Content Shell */}
        <div className="flex-1 flex overflow-hidden">
          {/* Scrollable Content (60%) */}
          <div className="flex-[0.6] overflow-y-auto px-12 py-12 space-y-12">
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h2 className="text-4xl font-display mb-6">1. The Intuition: Beyond Averages</h2>
              <p className="text-xl text-text-secondary leading-relaxed mb-8">
                In mathematics, we often talk about the <span className="text-text-primary font-bold">average rate of change</span>. 
                If you drive 100 miles in 2 hours, your average speed is 50 mph. But were you going 50 mph at 
                <span className="italic"> every single second</span>? No.
              </p>

              <ContentBox title="The Core Idea" type="intuition">
                The derivative is the answer to a seemingly impossible question: <strong>"How fast is something changing at a single, zero-width point in time?"</strong>
              </ContentBox>

              <p className="text-text-secondary leading-relaxed mb-6">
                Consider a ball dropped from a height. As it falls, it accelerates. Its speed is changing every millisecond. To find the speed at exactly $t = 2s$, we need to calculate the change in position over a time interval that shrinks to zero.
              </p>
            </motion.section>

            <motion.section
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl font-display mb-6">2. The Formal Definition</h2>
              <p className="text-text-secondary leading-relaxed mb-6">
                Let's formalize the idea of the secant line shrinking into a tangent line. Suppose we have a function $f(x)$. The average rate of change between $x$ and $x+h$ is:
              </p>
              
              <MathFormula formula="\frac{\Delta y}{\Delta x} = \frac{f(x + h) - f(x)}{h}" block />

              <p className="text-text-secondary leading-relaxed mb-6">
                The derivative, denoted as $f'(x)$ or $\frac{dy}{dx}$, is defined as the limit as $h$ approaches zero:
              </p>

              <div className="p-8 rounded-2xl bg-white/[0.02] border border-accent-cyan/20 glow-cyan my-8">
                <MathFormula formula="f'(x) = \lim_{h \to 0} \frac{f(x + h) - f(x)}{h}" block className="text-3xl text-accent-cyan" />
              </div>

              <ContentBox title="Historical Context" type="history">
                This definition was developed independently by <strong>Sir Isaac Newton</strong> and <strong>Gottfried Wilhelm Leibniz</strong> in the late 17th century. Newton called it the "Method of Fluxions," viewing variables as moving quantities. Leibniz focused on the notation of "infinitesimal" differences, which is why we still use his $\frac{dy}{dx}$ notation today.
              </ContentBox>
            </motion.section>

            <motion.section>
              <h2 className="text-4xl font-display mb-6">3. Check Understanding</h2>
              <div className="glass p-8 rounded-2xl border-accent-amber/20">
                <p className="text-lg mb-6">If $f(x) = x^2$, what is $f'(x)$ using the limit definition?</p>
                <div className="space-y-4 mb-8">
                  <button className="w-full p-4 rounded-xl border border-white/10 flex items-center gap-4 hover:bg-white/5 transition-all text-left">
                    <div className="w-6 h-6 rounded-lg border border-white/20 flex items-center justify-center font-mono text-xs">A</div>
                    <span>$f'(x) = 2x$</span>
                  </button>
                  <button className="w-full p-4 rounded-xl border border-white/10 flex items-center gap-4 hover:bg-white/5 transition-all text-left">
                    <div className="w-6 h-6 rounded-lg border border-white/20 flex items-center justify-center font-mono text-xs">B</div>
                    <span>$f'(x) = x$</span>
                  </button>
                </div>
                
                <HintBox hints={[
                  "Start by substituting $f(x+h) = (x+h)^2$ into the limit formula.",
                  "Expand $(x+h)^2$ into $x^2 + 2xh + h^2$.",
                  "Cancel out the $x^2$ terms, then divide everything by $h$ before taking the limit."
                ]} />
              </div>
            </motion.section>
          </div>

          {/* Interactive Panel (40%) */}
          <div className="flex-[0.4] bg-bg-tertiary border-l border-border flex flex-col">
            <div className="h-12 flex px-4 border-b border-border bg-bg-secondary">
              <button 
                onClick={() => setActiveTab('content')}
                className={cn(
                  "px-6 text-xs font-bold uppercase tracking-wider transition-colors",
                  activeTab === 'content' ? "border-b-2 border-accent-cyan text-accent-cyan" : "text-text-secondary"
                )}
              >
                Simulation
              </button>
              <button 
                onClick={() => setActiveTab('interactive')}
                className={cn(
                  "px-6 text-xs font-bold uppercase tracking-wider transition-colors",
                  activeTab === 'interactive' ? "border-b-2 border-accent-cyan text-accent-cyan" : "text-text-secondary"
                )}
              >
                Code Lab
              </button>
            </div>

            <div className="flex-1 overflow-hidden p-6">
              {activeTab === 'content' ? (
                <div className="h-full flex flex-col gap-6">
                  <div className="flex-1 glass rounded-2xl flex flex-col items-center justify-center relative overflow-hidden">
                    {/* Visual Mock: Simple D3/SVG demo would go here */}
                    <div className="text-center">
                      <div className="w-48 h-48 border-b-2 border-l-2 border-white/20 relative mx-auto mb-8">
                        <svg className="w-full h-full text-accent-cyan">
                          <motion.path 
                            d="M 10 180 Q 80 100 180 20" 
                            fill="none" 
                            stroke="currentColor" 
                            strokeWidth="2" 
                          />
                          <motion.line
                            x1="50" y1="130" x2="150" y2="30"
                            stroke="var(--color-accent-amber)"
                            strokeWidth="2"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ repeat: Infinity, duration: 2 }}
                          />
                        </svg>
                      </div>
                      <span className="text-xs font-mono text-text-secondary uppercase">Tangent Visualizer v1.02</span>
                    </div>
                  </div>
                  
                  <div className="p-6 glass rounded-2xl">
                    <h4 className="text-sm font-bold mb-4 flex items-center gap-2">
                       <Settings size={14} className="text-accent-cyan" /> PARAMETERS
                    </h4>
                    <div className="space-y-6">
                      <div>
                        <div className="flex justify-between text-[10px] font-mono mb-2 uppercase text-text-secondary">
                          <span>Point $x$</span>
                          <span>2.4</span>
                        </div>
                        <input type="range" className="w-full accent-accent-cyan" />
                      </div>
                      <div>
                        <div className="flex justify-between text-[10px] font-mono mb-2 uppercase text-text-secondary">
                          <span>Delta $h$</span>
                          <span>0.001</span>
                        </div>
                        <input type="range" className="w-full accent-accent-cyan" />
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col">
                  <div className="flex-1 rounded-2xl overflow-hidden border border-border">
                    <Editor
                      height="100%"
                      defaultLanguage="python"
                      theme="vs-dark"
                      value={`def derivative(f, x, h=0.00001):
    """
    Numerical approximation of the derivative
    using the limit definition.
    """
    return (f(x + h) - f(x)) / h

def f(x):
    return x**2

print(f"f'(2) = {derivative(f, 2)}")
# Expected output: 4.0000...`}
                      options={{
                        minimap: { enabled: false },
                        fontSize: 14,
                        fontFamily: 'JetBrains Mono',
                        scrollBeyondLastLine: false,
                        padding: { top: 20 }
                      }}
                    />
                  </div>
                  <button className="mt-4 w-full py-4 bg-accent-emerald text-black font-bold rounded-xl flex items-center justify-center gap-3 active:scale-[0.98] transition-all">
                    RUN EXPERIMENT <Play size={18} />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
