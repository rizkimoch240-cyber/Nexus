import React from 'react';
import { motion } from 'motion/react';
import { MasteryHeatmap } from '@/src/components/ui/MasteryHeatmap';
import { 
  Zap, 
  TrendingUp, 
  Target, 
  Clock, 
  Code,
  Flame,
  Award
} from 'lucide-react';
import { ProgressRing } from '@/src/components/ui/ProgressRing';

export const AnalyticsPage: React.FC = () => {
  return (
    <div className="p-8 max-w-7xl mx-auto space-y-12">
      <header>
        <h1 className="text-5xl font-display mb-2 text-gradient-cyan">INTELLECTUAL PROFILE</h1>
        <p className="text-text-secondary">Tracking your evolution through the STEM learning universe.</p>
      </header>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { icon: Zap, label: 'TOTAL XP', value: '14,285', color: 'text-accent-cyan' },
          { icon: Flame, label: 'STREAK', value: '12 DAYS', color: 'text-accent-amber' },
          { icon: Code, label: 'CODE EXPERIMENTS', value: '84', color: 'text-accent-emerald' },
          { icon: Award, label: 'RANK', value: 'ARCHITECT', color: 'text-accent-violet' },
        ].map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass p-6 rounded-2xl"
          >
            <stat.icon className={cn("mb-4", stat.color)} size={24} />
            <div className="text-xs font-mono text-text-secondary uppercase mb-1">{stat.label}</div>
            <div className="text-3xl font-display font-bold">{stat.value}</div>
          </motion.div>
        ))}
      </div>

      {/* Mastery Map */}
      <section className="glass p-8 rounded-2xl relative overflow-hidden">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-xl font-display font-bold flex items-center gap-2">
              <TrendingUp size={20} className="text-accent-cyan" /> LEARNING VELOCITY
            </h2>
            <p className="text-xs text-text-secondary">Quantifying concepts mastered over geological time scales.</p>
          </div>
          <div className="flex gap-2">
            {['1M', '3M', '1Y', 'ALL'].map(t => (
              <button key={t} className="px-3 py-1 text-[10px] font-mono border border-white/5 rounded-lg hover:bg-white/5">
                {t}
              </button>
            ))}
          </div>
        </div>
        <MasteryHeatmap />
      </section>

      {/* Detailed Analysis Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Radar Analysis */}
        <div className="lg:col-span-2 glass p-8 rounded-2xl">
          <h2 className="text-xl font-display font-bold mb-8 flex items-center gap-2">
            <Target size={20} className="text-accent-violet" /> COGNITIVE DEPTH ANALYSIS
          </h2>
          <div className="h-[400px] flex items-center justify-center relative">
             <div className="absolute inset-0 flex items-center justify-center opacity-10">
               {[...Array(5)].map((_, i) => (
                 <div key={i} className="absolute border border-white rounded-full" style={{ width: (i + 1) * 20 + '%', height: (i + 1) * 20 + '%' }} />
               ))}
               {[...Array(6)].map((_, i) => (
                 <div key={i} className="absolute h-full w-px bg-white" style={{ transform: `rotate(${i * 60}deg)` }} />
               ))}
             </div>
             {/* Radial labels */}
             <div className="absolute top-0 font-mono text-[10px] text-accent-cyan uppercase">Mathematics</div>
             <div className="absolute top-1/4 right-0 font-mono text-[10px] text-accent-emerald uppercase">Physics</div>
             <div className="absolute bottom-1/4 right-0 font-mono text-[10px] text-accent-violet uppercase">Chemistry</div>
             <div className="absolute bottom-0 font-mono text-[10px] text-accent-amber uppercase">Biology</div>
             <div className="absolute bottom-1/4 left-0 font-mono text-[10px] text-accent-rose uppercase">Engineering</div>
             <div className="absolute top-1/4 left-0 font-mono text-[10px] text-white uppercase">Compute</div>

             {/* The radar shape (CSS version) */}
             <div className="relative w-full h-full flex items-center justify-center">
                <svg className="w-full h-full drop-shadow-[0_0_20px_rgba(139,92,246,0.3)]">
                  <polygon 
                    points="200,50 350,150 320,300 200,350 80,300 50,150" 
                    fill="rgba(139,92,246,0.2)" 
                    stroke="var(--color-accent-violet)" 
                    strokeWidth="2" 
                    className="origin-center scale-75"
                  />
                </svg>
             </div>
          </div>
        </div>

        {/* Predictive Mastery Card */}
        <div className="space-y-6">
          <div className="glass p-8 rounded-2xl border-accent-emerald/20 bg-accent-emerald/5">
            <h3 className="text-sm font-bold uppercase tracking-widest mb-6 flex items-center gap-2">
               <Clock size={16} className="text-accent-emerald" /> PREDICTED MASTERY
            </h3>
            <div className="space-y-6">
              <div>
                <div className="flex justify-between text-xs font-mono mb-2">
                  <span>Calculus II</span>
                  <span className="text-accent-emerald">JUNE 2026</span>
                </div>
                <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                  <motion.div initial={{ width: 0 }} animate={{ width: '85%' }} className="h-full bg-accent-emerald" />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-xs font-mono mb-2">
                  <span>Linear Algebra</span>
                  <span className="text-accent-emerald">JULY 2026</span>
                </div>
                <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                  <motion.div initial={{ width: 0 }} animate={{ width: '42%' }} className="h-full bg-accent-emerald" />
                </div>
              </div>
            </div>
            <button className="w-full mt-10 py-4 glass glass-hover text-accent-emerald font-bold rounded-xl text-sm border-accent-emerald/20">
               OPTIMIZE PATH
            </button>
          </div>

          <div className="glass p-8 rounded-2xl">
             <h3 className="text-sm font-bold uppercase tracking-widest mb-6">Subject Mastery</h3>
             <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-white/5 rounded-xl">
                   <ProgressRing progress={0.88} size={60} color="var(--color-accent-cyan)" />
                   <div className="mt-2 text-[10px] font-mono text-text-secondary uppercase">Math</div>
                </div>
                <div className="text-center p-4 bg-white/5 rounded-xl">
                   <ProgressRing progress={0.42} size={60} color="var(--color-accent-emerald)" />
                   <div className="mt-2 text-[10px] font-mono text-text-secondary uppercase">Physics</div>
                </div>
                <div className="text-center p-4 bg-white/5 rounded-xl">
                   <ProgressRing progress={0.12} size={60} color="var(--color-accent-violet)" />
                   <div className="mt-2 text-[10px] font-mono text-text-secondary uppercase">Violet</div>
                </div>
                <div className="text-center p-4 bg-white/5 rounded-xl">
                   <ProgressRing progress={0.65} size={60} color="var(--color-accent-amber)" />
                   <div className="mt-2 text-[10px] font-mono text-text-secondary uppercase">Biology</div>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(' ');
}
