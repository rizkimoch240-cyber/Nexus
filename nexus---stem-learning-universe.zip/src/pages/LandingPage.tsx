import React from 'react';
import { motion } from 'motion/react';
import { SUBJECTS } from '@/src/data/curriculum';
import { SubjectCard } from '@/src/components/ui/SubjectCard';
import { ParticleField } from '@/src/components/layout/ParticleField';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Play, Trophy, Users } from 'lucide-react';

export const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen relative overflow-x-hidden">
      <ParticleField />
      
      <main className="relative z-10 px-6 pt-24 pb-20 max-w-7xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-24">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-accent-cyan/30 bg-accent-cyan/5 text-accent-cyan text-xs font-mono font-bold mb-8 glow-cyan"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent-cyan opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-accent-cyan"></span>
            </span>
            SYSTEM ONLINE — VERSION 2.0.4 - "PROMETHEUS"
          </motion.div>
          
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-6xl md:text-8xl lg:text-9xl font-display mb-8 leading-[0.9] tracking-tighter"
          >
            BECOME <span className="text-gradient-cyan">INFINITE</span>.
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-text-secondary text-xl md:text-2xl max-w-2xl mx-auto leading-relaxed mb-12"
          >
            From zero to research frontier. A recursively deep learning universe 
            built for masters, by architects.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-wrap items-center justify-center gap-6"
          >
            <button 
              onClick={() => navigate('/curriculum')}
              className="px-10 py-5 bg-accent-cyan text-black font-bold rounded-2xl flex items-center gap-3 hover:scale-105 transition-all glow-cyan"
            >
              START EXPLORATION <ArrowRight size={20} />
            </button>
            <button className="px-10 py-5 glass glass-hover text-white font-bold rounded-2xl flex items-center gap-3">
              WATCH TRAILER <Play size={20} />
            </button>
          </motion.div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-32">
          {[
            { icon: Users, label: 'ACTIVE EXPLORERS', value: '142,804' },
            { icon: Play, label: 'TOTAL CHAPTERS', value: '4,281' },
            { icon: Trophy, label: 'RESEARCH PAPERS UNLOCKED', value: '12,042' },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass p-8 rounded-2xl text-center"
            >
              <stat.icon className="mx-auto mb-4 text-accent-cyan opacity-50" size={32} />
              <div className="text-4xl font-display font-bold mb-2">{stat.value}</div>
              <div className="text-xs font-mono text-text-secondary tracking-[0.2em]">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Subject Grid */}
        <div id="subjects" className="space-y-12 mb-32">
          <div className="text-center">
            <h2 className="text-4xl md:text-5xl font-display mb-4">CHOOSE YOUR DISCIPLINE</h2>
            <div className="w-24 h-1 bg-gradient-to-r from-accent-cyan to-accent-violet mx-auto rounded-full" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {SUBJECTS.map((subject, i) => (
              <motion.div
                key={subject.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
              >
                <SubjectCard 
                  {...subject} 
                  level={0} 
                  onClick={() => navigate(`/curriculum/${subject.id}`)}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </main>
      
      {/* Footer Decoration */}
      <div className="h-64 bg-gradient-to-t from-accent-cyan/10 to-transparent pointer-events-none" />
    </div>
  );
};
