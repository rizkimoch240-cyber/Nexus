import { 
  Sigma, 
  Atom, 
  Beaker, 
  Dna, 
  Settings, 
  Terminal, 
  Database 
} from 'lucide-react';

export const SUBJECTS = [
  {
    id: 'math',
    title: 'Mathematics',
    icon: Sigma,
    color: '#00D4FF',
    description: 'From counting to category theory. The language of the universe.',
    lessons: 450,
  },
  {
    id: 'physics',
    title: 'Physics',
    icon: Atom,
    color: '#10B981',
    description: 'Energy, matter, and the fundamental laws of reality.',
    lessons: 380,
  },
  {
    id: 'chemistry',
    title: 'Chemistry',
    icon: Beaker,
    color: '#8B5CF6',
    description: 'The molecular dance and the building blocks of life.',
    lessons: 320,
  },
  {
    id: 'biology',
    title: 'Biology',
    icon: Dna,
    color: '#F59E0B',
    description: 'Complexity from simple rules. The science of living systems.',
    lessons: 290,
  },
  {
    id: 'engineering',
    title: 'Engineering',
    icon: Settings,
    color: '#F43F5E',
    description: 'Transforming theory into reality. Building the future.',
    lessons: 210,
  },
  {
    id: 'cs',
    title: 'Computer Science',
    icon: Terminal,
    color: '#F0F0F8',
    description: 'Algorithms, complexity, and the logic of computation.',
    lessons: 410,
  },
  {
    id: 'data',
    title: 'Data Science',
    icon: Database,
    color: '#7DD3FC',
    description: 'Extracting truth from noise in a digital world.',
    lessons: 180,
  },
];

export const SKILL_TREE_DATA = {
  nodes: [
    { id: 'arithmetic', label: 'Arithmetic', level: 0, subject: 'math' },
    { id: 'algebra-1', label: 'Algebra I', level: 1, subject: 'math' },
    { id: 'geometry', label: 'Geometry', level: 1, subject: 'math' },
    { id: 'algebra-2', label: 'Algebra II', level: 2, subject: 'math' },
    { id: 'trigonometry', label: 'Trigonometry', level: 2, subject: 'math' },
    { id: 'pre-calc', label: 'Pre-Calculus', level: 2, subject: 'math' },
    { id: 'calculus-1', label: 'Calculus I', level: 3, subject: 'math', current: true },
    { id: 'linear-algebra', label: 'Linear Algebra', level: 3, subject: 'math' },
    { id: 'multi-calc', label: 'Multivariable Calculus', level: 4, subject: 'math' },
    { id: 'diff-eq', label: 'Differential Equations', level: 4, subject: 'math' },
    { id: 'real-analysis', label: 'Real Analysis', level: 5, subject: 'math' },
    { id: 'topology', label: 'Topology', level: 5, subject: 'math' },
  ],
  links: [
    { source: 'arithmetic', target: 'algebra-1' },
    { source: 'algebra-1', target: 'geometry' },
    { source: 'algebra-1', target: 'algebra-2' },
    { source: 'algebra-2', target: 'trigonometry' },
    { source: 'trigonometry', target: 'pre-calc' },
    { source: 'algebra-2', target: 'pre-calc' },
    { source: 'pre-calc', target: 'calculus-1' },
    { source: 'calculus-1', target: 'multi-calc' },
    { source: 'linear-algebra', target: 'multi-calc' },
    { source: 'multi-calc', target: 'diff-eq' },
    { source: 'diff-eq', target: 'real-analysis' },
    { source: 'real-analysis', target: 'topology' },
  ]
};
