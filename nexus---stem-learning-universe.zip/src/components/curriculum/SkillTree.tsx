import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { motion } from 'motion/react';
import { SKILL_TREE_DATA } from '@/src/data/curriculum';

interface SkillTreeProps {
  className?: string;
  onNodeClick?: (nodeId: string) => void;
}

export const SkillTree: React.FC<SkillTreeProps> = ({ className, onNodeClick }) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;

    const width = containerRef.current.clientWidth;
    const height = 600;

    const svg = d3.select(svgRef.current)
      .attr('viewBox', [0, 0, width, height])
      .attr('style', 'max-width: 100%; height: auto;');

    svg.selectAll('*').remove();

    const g = svg.append('g');

    // Force simulation
    const simulation = d3.forceSimulation(SKILL_TREE_DATA.nodes as any)
      .force('link', d3.forceLink(SKILL_TREE_DATA.links).id((d: any) => d.id).distance(100))
      .force('charge', d3.forceManyBody().strength(-500))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('x', d3.forceX(width / 2).strength(0.1))
      .force('y', d3.forceY((d: any) => d.level * 100 + 50).strength(0.5));

    // Links
    const link = g.append('g')
      .attr('stroke', 'rgba(255,255,255,0.1)')
      .selectAll('line')
      .data(SKILL_TREE_DATA.links)
      .join('line')
      .attr('stroke-width', 2);

    // Nodes
    const node = g.append('g')
      .selectAll('g')
      .data(SKILL_TREE_DATA.nodes)
      .join('g')
      .attr('cursor', 'pointer')
      .on('click', (event, d: any) => onNodeClick?.(d.id))
      .call(d3.drag()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended) as any);

    // Node Background
    node.append('circle')
      .attr('r', 30)
      .attr('fill', (d: any) => d.current ? 'var(--color-accent-cyan)' : 'var(--color-bg-tertiary)')
      .attr('stroke', (d: any) => d.current ? 'white' : 'rgba(255,255,255,0.1)')
      .attr('stroke-width', 2)
      .attr('class', 'transition-colors duration-300');

    // Node Text
    node.append('text')
      .attr('dy', 45)
      .attr('text-anchor', 'middle')
      .attr('fill', 'var(--color-text-secondary)')
      .attr('font-size', '10px')
      .attr('font-weight', 'bold')
      .attr('class', 'select-none pointer-events-none')
      .text((d: any) => d.label.toUpperCase());

    // Level Indicator (node center)
    node.append('text')
      .attr('dy', 5)
      .attr('text-anchor', 'middle')
      .attr('fill', (d: any) => d.current ? 'black' : 'var(--color-accent-cyan)')
      .attr('font-size', '14px')
      .attr('font-weight', 'bold')
      .attr('class', 'select-none pointer-events-none font-display')
      .text((d: any) => d.level);

    simulation.on('tick', () => {
      link
        .attr('x1', (d: any) => d.source.x)
        .attr('y1', (d: any) => d.source.y)
        .attr('x2', (d: any) => d.target.x)
        .attr('y2', (d: any) => d.target.y);

      node
        .attr('transform', (d: any) => `translate(${d.x},${d.y})`);
    });

    function dragstarted(event: any) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      event.subject.fx = event.subject.x;
      event.subject.fy = event.subject.y;
    }

    function dragged(event: any) {
      event.subject.fx = event.x;
      event.subject.fy = event.y;
    }

    function dragended(event: any) {
      if (!event.active) simulation.alphaTarget(0);
      event.subject.fx = null;
      event.subject.fy = null;
    }

    // Zoom and Pan
    svg.call(d3.zoom()
      .extent([[0, 0], [width, height]])
      .scaleExtent([0.5, 2])
      .on('zoom', (event) => {
        g.attr('transform', event.transform);
      }) as any);

  }, [onNodeClick]);

  return (
    <div ref={containerRef} className={cn("relative w-full overflow-hidden glass rounded-2xl", className)}>
      <svg ref={svgRef} className="w-full h-full" />
      <div className="absolute top-4 left-4 flex gap-2 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1 bg-black/40 rounded-full border border-white/10 text-[10px] text-text-secondary">
          <div className="w-2 h-2 rounded-full bg-accent-cyan" /> COMPLETED / CURRENT
        </div>
        <div className="flex items-center gap-2 px-3 py-1 bg-black/40 rounded-full border border-white/10 text-[10px] text-text-secondary">
          <div className="w-2 h-2 rounded-full bg-white/10" /> LOCKED
        </div>
      </div>
    </div>
  );
};
