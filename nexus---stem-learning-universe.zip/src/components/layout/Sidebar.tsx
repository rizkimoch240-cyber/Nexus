import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, 
  Map, 
  BookOpen, 
  BarChart2, 
  Settings, 
  LogOut, 
  ChevronLeft, 
  ChevronRight,
  Zap,
  Search
} from 'lucide-react';
import { useStore } from '@/src/store/useStore';
import { formatXP } from '@/src/lib/utils';
import { cn } from '@/src/lib/utils';

export const Sidebar: React.FC = () => {
  const [collapsed, setCollapsed] = useState(false);
  const user = useStore(state => state.user);

  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: Map, label: 'Curriculum', path: '/curriculum' },
    { icon: BookOpen, label: 'Lessons', path: '/lessons' },
    { icon: BarChart2, label: 'Analytics', path: '/analytics' },
  ];

  return (
    <motion.aside
      animate={{ width: collapsed ? 80 : 280 }}
      className="h-screen sticky top-0 bg-bg-secondary border-r border-border flex flex-col z-50"
    >
      {/* Profile Section */}
      <div className="p-6">
        <div className={cn("flex items-center gap-4 mb-8", collapsed && "justify-center")}>
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-accent-cyan to-accent-violet p-0.5">
              <div className="w-full h-full rounded-full bg-bg-primary flex items-center justify-center font-bold text-sm">
                NX
              </div>
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-accent-emerald border-2 border-bg-secondary rounded-full" />
          </div>
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex flex-col"
            >
              <span className="font-bold text-sm">Explorer 729</span>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-[10px] font-mono text-accent-cyan">LEVEL 12</span>
                <div className="flex items-center gap-1 text-[10px] font-mono text-text-secondary bg-white/5 px-2 py-0.5 rounded-full">
                  <Zap size={10} className="text-accent-amber" />
                  {formatXP(user.xp)} XP
                </div>
              </div>
            </motion.div>
          )}
        </div>

        {/* Search Trigger */}
        <button className={cn(
          "w-full flex items-center gap-3 px-4 py-2 bg-white/5 hover:bg-white/10 rounded-xl border border-white/5 transition-all text-text-secondary mb-6",
          collapsed && "justify-center px-0"
        )}>
          <Search size={18} />
          {!collapsed && <span className="text-xs">Search (⌘K)</span>}
        </button>

        {/* Nav Items */}
        <nav className="space-y-2">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => cn(
                "flex items-center gap-4 px-4 py-3 rounded-xl transition-all group relative",
                collapsed && "justify-center",
                isActive ? "bg-accent-cyan/10 text-accent-cyan shadow-[0_0_15px_rgba(0,212,255,0.1)]" : "text-text-secondary hover:text-text-primary hover:bg-white/5"
              )}
            >
              <item.icon size={20} />
              {!collapsed && <span className="font-medium text-sm">{item.label}</span>}
              {!collapsed && (
                <div className="ml-auto w-1 h-1 rounded-full bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity" />
              )}
            </NavLink>
          ))}
        </nav>
      </div>

      {/* Bottom Actions */}
      <div className="mt-auto p-6 space-y-2">
        <button className={cn(
          "w-full flex items-center gap-4 px-4 py-3 rounded-xl text-text-secondary hover:text-text-primary hover:bg-white/5 transition-all",
          collapsed && "justify-center"
        )}>
          <Settings size={20} />
          {!collapsed && <span className="font-medium text-sm">Settings</span>}
        </button>
        <button 
          onClick={() => setCollapsed(!collapsed)}
          className={cn(
            "w-full flex items-center gap-4 px-4 py-3 rounded-xl text-text-secondary hover:text-text-primary hover:bg-white/5 transition-all",
            collapsed && "justify-center"
          )}
        >
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
          {!collapsed && <span className="font-medium text-sm">Collapse</span>}
        </button>
      </div>
    </motion.aside>
  );
};
