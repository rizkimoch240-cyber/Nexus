import React from 'react';
import { Lightbulb, History, Info } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '@/src/lib/utils';

interface ContentBoxProps {
  title: string;
  type: 'intuition' | 'history' | 'matters' | 'research';
  children: React.ReactNode;
  className?: string;
}

export const ContentBox: React.FC<ContentBoxProps> = ({ title, type, children, className }) => {
  const configs = {
    intuition: {
      icon: Lightbulb,
      color: "var(--color-accent-amber)",
      bg: "bg-accent-amber/5",
      border: "border-accent-amber/20"
    },
    history: {
      icon: History,
      color: "var(--color-accent-violet)",
      bg: "bg-accent-violet/5",
      border: "border-accent-violet/20"
    },
    matters: {
      icon: Info,
      color: "var(--color-accent-emerald)",
      bg: "bg-accent-emerald/5",
      border: "border-accent-emerald/20"
    },
    research: {
      icon: Info,
      color: "var(--color-accent-rose)",
      bg: "bg-accent-rose/5",
      border: "border-accent-rose/20"
    }
  };

  const config = configs[type];
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      className={cn(
        "p-6 rounded-2xl border-l-[6px] my-8",
        config.bg,
        config.border,
        className
      )}
    >
      <div className="flex items-center gap-2 mb-3" style={{ color: config.color }}>
        <Icon size={20} />
        <span className="font-display font-bold uppercase tracking-wider text-sm">{title}</span>
      </div>
      <div className="prose prose-invert max-w-none text-text-secondary leading-relaxed">
        {children}
      </div>
    </motion.div>
  );
};
