import React, { useState } from 'react';
import { ChevronDown, ChevronUp, CheckCircle2, Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';

interface HintBoxProps {
  hints: string[];
}

export const HintBox: React.FC<HintBoxProps> = ({ hints }) => {
  const [revealedCount, setRevealedCount] = useState(0);

  const getLabel = (index: number) => {
    if (index === 0) return "Subtle Hint";
    if (index === 1) return "Moderate Hint";
    return "Direct Revelation";
  };

  return (
    <div className="space-y-3 my-6">
      {hints.map((hint, i) => {
        const isRevealed = i < revealedCount;
        const isNextToReveal = i === revealedCount;

        return (
          <div 
            key={i}
            className={cn(
              "rounded-xl border transition-all duration-300 overflow-hidden",
              isRevealed ? "bg-white/5 border-white/10" : "bg-black/20 border-white/5"
            )}
          >
            <button
              onClick={() => isNextToReveal && setRevealedCount(i + 1)}
              disabled={!isNextToReveal && !isRevealed}
              className={cn(
                "w-full px-4 py-3 flex items-center justify-between text-sm transition-colors",
                isNextToReveal ? "hover:bg-accent-cyan/10 cursor-pointer" : "cursor-default"
              )}
            >
              <div className="flex items-center gap-3">
                {isRevealed ? (
                  <CheckCircle2 size={16} className="text-accent-emerald" />
                ) : (
                  <Lock size={16} className={isNextToReveal ? "text-accent-cyan" : "text-white/20"} />
                )}
                <span className={cn(
                  "font-bold uppercase tracking-tighter",
                  isRevealed ? "text-text-primary" : (isNextToReveal ? "text-accent-cyan" : "text-white/20")
                )}>
                  {getLabel(i)}
                </span>
              </div>
              {!isRevealed && isNextToReveal && (
                <span className="text-[10px] bg-accent-cyan/20 text-accent-cyan px-2 py-0.5 rounded uppercase">Unlock</span>
              )}
            </button>
            
            <AnimatePresence>
              {isRevealed && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="px-4 pb-4 text-text-secondary leading-relaxed border-t border-white/5 pt-3"
                >
                  {hint}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        );
      })}
    </div>
  );
};
