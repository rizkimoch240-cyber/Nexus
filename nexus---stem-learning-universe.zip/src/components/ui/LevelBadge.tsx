import React from 'react';
import { motion } from 'motion/react';

interface LevelBadgeProps {
  level: number;
  color?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const LevelBadge: React.FC<LevelBadgeProps> = ({ 
  level, 
  color = "var(--color-accent-cyan)",
  size = 'md' 
}) => {
  const sizes = {
    sm: 'px-2 py-0.5 text-[10px]',
    md: 'px-3 py-1 text-xs',
    lg: 'px-4 py-1.5 text-sm',
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`${sizes[size]} font-mono font-bold rounded-full border bg-black/40`}
      style={{ borderColor: `${color}40`, color: color }}
    >
      LEVEL {level}
    </motion.div>
  );
};
