import React from 'react';
import { motion } from 'motion/react';

interface MasteryHeatmapProps {
  data?: number[]; // simplified for demo
}

export const MasteryHeatmap: React.FC<MasteryHeatmapProps> = ({ data }) => {
  // Generate random data for 52 weeks * 7 days
  const days = [...Array(364)].map(() => Math.floor(Math.random() * 5));

  const getColor = (level: number) => {
    switch (level) {
      case 0: return 'bg-white/5';
      case 1: return 'bg-accent-cyan/20';
      case 2: return 'bg-accent-cyan/40';
      case 3: return 'bg-accent-cyan/70';
      case 4: return 'bg-accent-cyan';
      default: return 'bg-white/5';
    }
  };

  return (
    <div className="overflow-x-auto pb-4">
      <div className="flex gap-1">
        {[...Array(52)].map((_, weekIndex) => (
          <div key={weekIndex} className="flex flex-col gap-1">
            {[...Array(7)].map((_, dayIndex) => {
              const dayValue = days[weekIndex * 7 + dayIndex];
              return (
                <motion.div
                  key={dayIndex}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: (weekIndex * 7 + dayIndex) * 0.001 }}
                  className={`w-3 h-3 rounded-sm ${getColor(dayValue)} hover:ring-2 hover:ring-white/50 transition-all cursor-pointer`}
                  title={`Level ${dayValue} Mastery achieved on this day`}
                />
              );
            })}
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center justify-end gap-2 text-[10px] font-mono text-text-secondary uppercase">
        <span>Less</span>
        <div className="w-3 h-3 rounded-sm bg-white/5" />
        <div className="w-3 h-3 rounded-sm bg-accent-cyan/20" />
        <div className="w-3 h-3 rounded-sm bg-accent-cyan/40" />
        <div className="w-3 h-3 rounded-sm bg-accent-cyan/70" />
        <div className="w-3 h-3 rounded-sm bg-accent-cyan" />
        <span>More</span>
      </div>
    </div>
  );
};
