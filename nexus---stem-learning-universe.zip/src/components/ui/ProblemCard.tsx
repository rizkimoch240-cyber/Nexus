import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, XCircle, ArrowRight, HelpCircle } from 'lucide-react';
import { MathFormula } from './MathFormula';
import { HintBox } from './HintBox';
import { cn } from '@/src/lib/utils';

interface ProblemCardProps {
  id: string;
  question: string;
  options?: string[];
  solution: React.ReactNode;
  difficulty: 'Routine' | 'Challenging' | 'Competition' | 'Research';
  type: 'MCQ' | 'FREE_FORM';
  hints: string[];
}

export const ProblemCard: React.FC<ProblemCardProps> = ({
  question,
  options,
  solution,
  difficulty,
  type,
  hints
}) => {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showSolution, setShowSolution] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  const difficultyColors = {
    Routine: 'text-accent-emerald bg-accent-emerald/10',
    Challenging: 'text-accent-cyan bg-accent-cyan/10',
    Competition: 'text-accent-amber bg-accent-amber/10',
    Research: 'text-accent-rose bg-accent-rose/10',
  };

  const handleCheck = () => {
    if (selectedOption === 0) { // Assuming 0 is correct for demo
      setIsCorrect(true);
      setShowSolution(true);
    } else {
      setIsCorrect(false);
    }
  };

  return (
    <div className="glass p-8 rounded-2xl border-white/5 space-y-6">
      <div className="flex justify-between items-center">
        <span className={cn("px-3 py-1 rounded-full text-[10px] font-mono font-bold uppercase", difficultyColors[difficulty])}>
          {difficulty}
        </span>
        <div className="flex items-center gap-2 text-text-secondary text-xs font-mono">
          <HelpCircle size={14} /> ID: PR-1024
        </div>
      </div>

      <div className="text-lg leading-relaxed">
        <MathFormula formula={question} />
      </div>

      {type === 'MCQ' && options && (
        <div className="space-y-3">
          {options.map((opt, i) => (
            <button
              key={i}
              onClick={() => setSelectedOption(i)}
              className={cn(
                "w-full p-4 rounded-xl border transition-all text-left flex items-center gap-4",
                selectedOption === i 
                  ? "bg-accent-cyan/10 border-accent-cyan text-accent-cyan" 
                  : "bg-white/5 border-white/5 text-text-secondary hover:border-white/20"
              )}
            >
              <div className={cn(
                "w-6 h-6 rounded flex items-center justify-center font-mono text-xs border",
                selectedOption === i ? "border-accent-cyan" : "border-white/20"
              )}>
                {String.fromCharCode(65 + i)}
              </div>
              <MathFormula formula={opt} />
            </button>
          ))}
        </div>
      )}

      <div className="flex gap-4 pt-4">
        <button 
          onClick={handleCheck}
          className="flex-1 py-4 bg-accent-cyan text-black font-bold rounded-xl flex items-center justify-center gap-2 hover:scale-[1.02] active:scale-[0.98] transition-all"
        >
          CHECK ANSWER <CheckCircle2 size={18} />
        </button>
      </div>

      <AnimatePresence>
        {isCorrect === false && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 bg-accent-rose/10 border border-accent-rose/20 rounded-xl flex items-center gap-3 text-accent-rose text-sm"
          >
            <XCircle size={18} /> Incorrect. Try revisiting the intuition section or use a hint.
          </motion.div>
        )}
      </AnimatePresence>

      <HintBox hints={hints} />

      <AnimatePresence>
        {showSolution && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="pt-6 border-t border-white/10"
          >
            <h4 className="text-sm font-bold text-accent-emerald mb-4 uppercase tracking-wider">Worked Solution</h4>
            <div className="prose prose-invert max-w-none text-text-secondary">
              {solution}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
