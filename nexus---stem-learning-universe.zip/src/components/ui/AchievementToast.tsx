import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Trophy, Star, X } from 'lucide-react';

interface AchievementToastProps {
  id: string;
  title: string;
  description: string;
  onClose: () => void;
}

export const AchievementToast: React.FC<AchievementToastProps> = ({ title, description, onClose }) => {
  return (
    <motion.div
      initial={{ x: 400, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 400, opacity: 0 }}
      className="fixed bottom-8 right-8 z-[100] w-96 glass p-6 rounded-2xl border-accent-amber/30 shadow-2xl relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 p-4">
        <button onClick={onClose} className="text-white/20 hover:text-white transition-colors">
          <X size={16} />
        </button>
      </div>

      <div className="flex items-center gap-6">
        <div className="relative">
          <div className="w-16 h-16 rounded-2xl bg-accent-amber/20 border border-accent-amber/40 flex items-center justify-center text-accent-amber relative z-10">
            <Trophy size={32} />
          </div>
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 scale-150 opacity-20 pointer-events-none"
          >
            <Star className="text-accent-amber" />
          </motion.div>
        </div>

        <div>
          <div className="text-[10px] font-mono font-bold text-accent-amber uppercase tracking-widest mb-1">Achievement Unlocked</div>
          <h3 className="font-display font-bold text-lg mb-1">{title}</h3>
          <p className="text-xs text-text-secondary leading-relaxed">{description}</p>
        </div>
      </div>

      <div className="mt-4 h-1 w-full bg-white/5 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: '100%' }}
          animate={{ width: 0 }}
          transition={{ duration: 5, ease: "linear" }}
          onAnimationComplete={onClose}
          className="h-full bg-accent-amber"
        />
      </div>
    </motion.div>
  );
};
