import React, { useEffect, useRef } from 'react';
import katex from 'katex';
import { cn } from '@/src/lib/utils';

interface MathFormulaProps {
  formula: string;
  block?: boolean;
  className?: string;
}

export const MathFormula: React.FC<MathFormulaProps> = ({ formula, block = false, className }) => {
  const containerRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      katex.render(formula, containerRef.current, {
        throwOnError: false,
        displayMode: block,
      });
    }
  }, [formula, block]);

  return (
    <span 
      ref={containerRef} 
      className={cn(
        "inline-block", 
        block && "block w-full text-center",
        className
      )} 
    />
  );
};
