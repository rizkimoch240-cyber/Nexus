import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Command, Search, Sparkles } from 'lucide-react';

export const CommandPalette: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen(prev => !prev);
      }
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-start justify-center pt-[15vh] px-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-2xl glass rounded-2xl shadow-2xl overflow-hidden border-white/10"
          >
            <div className="p-6 flex items-center gap-4 bg-white/5 border-b border-white/5">
              <Search className="text-accent-cyan" size={24} />
              <input
                autoFocus
                placeholder="What would you like to master today?"
                className="w-full bg-transparent border-none focus:ring-0 text-xl font-display outline-none placeholder:text-text-secondary"
              />
              <div className="flex items-center gap-1 px-2 py-1 bg-white/10 rounded-lg text-[10px] font-mono text-text-secondary">
                <Command size={10} /> K
              </div>
            </div>

            <div className="p-4 space-y-2 max-h-[400px] overflow-y-auto">
              <div className="px-4 py-2 text-[10px] font-mono text-text-secondary uppercase tracking-widest">Recommended Paths</div>
              {[
                { label: 'Derivative Properties', subject: 'Mathematics', desc: 'Prove the power rule from first principles' },
                { label: 'Quantum Entanglement', subject: 'Physics', desc: 'Level 5 — Mastery of non-local states' },
                { label: 'Neural Networks', subject: 'CS', desc: 'Interactive backpropagation visualizer' },
              ].map((item, i) => (
                <button 
                  key={i}
                  className="w-full p-4 rounded-xl hover:bg-white/5 flex items-start gap-4 text-left group transition-all"
                >
                  <div className="p-2 rounded-lg bg-black/40 border border-white/5 group-hover:border-accent-cyan transition-colors">
                    <Sparkles size={16} className="text-accent-cyan" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold">{item.label}</span>
                      <span className="text-[10px] px-1.5 py-0.5 bg-white/5 rounded text-text-secondary uppercase">{item.subject}</span>
                    </div>
                    <p className="text-xs text-text-secondary">{item.desc}</p>
                  </div>
                </button>
              ))}
            </div>

            <div className="p-4 border-t border-white/5 flex justify-between items-center text-[10px] font-mono text-text-secondary">
              <div className="flex gap-4">
                <span><kbd className="bg-white/10 px-1 rounded">↑↓</kbd> SELECT</span>
                <span><kbd className="bg-white/10 px-1 rounded">ENTER</kbd> EXECUTE</span>
              </div>
              <div className="flex gap-4">
                <span><kbd className="bg-white/10 px-1 rounded">ESC</kbd> CLOSE</span>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
