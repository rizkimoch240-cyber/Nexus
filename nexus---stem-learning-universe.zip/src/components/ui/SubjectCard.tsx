import React from 'react';
import { motion } from 'motion/react';
import { LucideIcon } from 'lucide-react';
import { LevelBadge } from './LevelBadge';
import { cn } from '@/src/lib/utils';

interface SubjectCardProps {
  id: string;
  title: string;
  icon: LucideIcon;
  color: string;
  level: number;
  lessons: number;
  description: string;
  onClick?: () => void;
}

export const SubjectCard: React.FC<SubjectCardProps> = ({
  title,
  icon: Icon,
  color,
  level,
  lessons,
  description,
  onClick
}) => {
  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -5 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="glass glass-hover p-6 rounded-2xl cursor-pointer group"
    >
      <div className="flex justify-between items-start mb-4">
        <div 
          className="p-3 rounded-xl transition-colors duration-300"
          style={{ backgroundColor: `${color}15`, color: color }}
        >
          <Icon size={24} />
        </div>
        <LevelBadge level={level} color={color} />
      </div>
      
      <h3 className="text-xl font-display mb-2 group-hover:text-white transition-colors">
        {title}
      </h3>
      <p className="text-text-secondary text-sm mb-4 line-clamp-2">
        {description}
      </p>
      
      <div className="flex items-center gap-4 text-xs font-mono text-text-secondary">
        <span>{lessons} LESSONS</span>
        <div className="w-1 h-1 rounded-full bg-white/20" />
        <span>MASTERY: 0%</span>
      </div>
      
      <div 
        className="mt-6 h-1 w-0 group-hover:w-full transition-all duration-500 rounded-full"
        style={{ backgroundColor: color }}
      />
    </motion.div>
  );
};
