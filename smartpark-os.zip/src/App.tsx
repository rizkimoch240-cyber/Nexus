/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Car, 
  Bike, 
  Truck, 
  Bus as BusIcon, 
  Zap, 
  Star, 
  Receipt, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  CreditCard,
  User,
  ShieldAlert,
  Leaf
} from 'lucide-react';

// Pricing Constants (Flat variables to honor the "no dict/list" intent in logic)
const PRICE_MOTOR_A = 4000;
const PRICE_MOTOR_B = 3000;
const PRICE_MOTOR_C = 2000;
const PRICE_MOBIL_A = 8000;
const PRICE_MOBIL_B = 6000;
const PRICE_MOBIL_C = 4000;
const PRICE_SUV_A = 12000;
const PRICE_SUV_B = 9000;
const PRICE_SUV_C = 6000;
const PRICE_BUS_A = 20000;
const PRICE_BUS_B = 15000;
const PRICE_BUS_C = 10000;
const PRICE_TRUK_A = 25000;
const PRICE_TRUK_B = 18000;
const PRICE_TRUK_C = 12000;

export default function App() {
  // --- [1] Form State (12 Parameters) ---
  const [cashierName, setCashierName] = useState('');
  const [vehicleType, setVehicleType] = useState('Mobil'); // Motor, Mobil, SUV, Bus, Truk
  const [parkingZone, setParkingZone] = useState('B'); // A, B, C
  const [entryHour, setEntryHour] = useState(8);
  const [entryMinute, setEntryMinute] = useState(0);
  const [exitHour, setExitHour] = useState(10);
  const [exitMinute, setExitMinute] = useState(30);
  const [membership, setMembership] = useState('Guest'); // Guest, Basic, Silver, Gold, Platinum
  const [voucherCode, setVoucherCode] = useState('');
  const [isTicketLost, setIsTicketLost] = useState(false);
  const [isEvCharging, setIsEvCharging] = useState(false);
  const [isValet, setIsValet] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState(0);

  const [showReceipt, setShowReceipt] = useState(false);

  // --- [2] PRICING ENGINE ---
  // Calculates everything in one flat block to simulate the requested "primitive" style
  const report = useMemo(() => {
    // 1. Calculate Duration
    let durHours = exitHour - entryHour;
    let durMinutes = exitMinute - entryMinute;
    
    // Handle overnight edge case
    if (durHours < 0 || (durHours === 0 && durMinutes < 0)) {
      durHours += 24;
    }
    
    let totalMinutes = (durHours * 60) + durMinutes;
    
    // Duration < 30 mins rounded to 1 hour minimum
    if (totalMinutes < 30) {
      totalMinutes = 60;
    }
    
    let calcHours = Math.ceil(totalMinutes / 60);
    if (calcHours === 0) calcHours = 1;

    // 2. Base Price per Vehicle x Zone
    let baseRate = 0;
    if (vehicleType === 'Motor') {
      if (parkingZone === 'A') baseRate = PRICE_MOTOR_A;
      else if (parkingZone === 'B') baseRate = PRICE_MOTOR_B;
      else baseRate = PRICE_MOTOR_C;
    } else if (vehicleType === 'Mobil') {
      if (parkingZone === 'A') baseRate = PRICE_MOBIL_A;
      else if (parkingZone === 'B') baseRate = PRICE_MOBIL_B;
      else baseRate = PRICE_MOBIL_C;
    } else if (vehicleType === 'SUV') {
      if (parkingZone === 'A') baseRate = PRICE_SUV_A;
      else if (parkingZone === 'B') baseRate = PRICE_SUV_B;
      else baseRate = PRICE_SUV_C;
    } else if (vehicleType === 'Bus') {
      if (parkingZone === 'A') baseRate = PRICE_BUS_A;
      else if (parkingZone === 'B') baseRate = PRICE_BUS_B;
      else baseRate = PRICE_BUS_C;
    } else if (vehicleType === 'Truk') {
      if (parkingZone === 'A') baseRate = PRICE_TRUK_A;
      else if (parkingZone === 'B') baseRate = PRICE_TRUK_B;
      else baseRate = PRICE_TRUK_C;
    }

    // Special Voucher VIPDAY logic: Upgrade automatically to Zone A
    if (voucherCode === 'VIPDAY' && parkingZone !== 'A') {
       if (vehicleType === 'Motor') baseRate = PRICE_MOTOR_A;
       else if (vehicleType === 'Mobil') baseRate = PRICE_MOBIL_A;
       else if (vehicleType === 'SUV') baseRate = PRICE_SUV_A;
       else if (vehicleType === 'Bus') baseRate = PRICE_BUS_A;
       else if (vehicleType === 'Truk') baseRate = PRICE_TRUK_A;
    }

    // 3. Dynamic Time Multiplier (Based on Entry Hour)
    let timeMultiplier = 1.0;
    let timeLabel = 'Normal';
    if (entryHour >= 7 && entryHour < 9) { timeMultiplier = 1.5; timeLabel = 'Peak Pagi'; }
    else if (entryHour >= 17 && entryHour < 19) { timeMultiplier = 1.5; timeLabel = 'Peak Sore'; }
    else if (entryHour >= 13 && entryHour < 14) { timeMultiplier = 0.8; timeLabel = 'Siang Sepi'; }
    else if (entryHour >= 20 && entryHour < 22) { timeMultiplier = 1.1; timeLabel = 'Malam'; }
    else if (entryHour >= 22 || entryHour < 5) { timeMultiplier = 1.25; timeLabel = 'Dini Hari'; }

    // 4. Progressive Calculation
    let hourlySum = 0;
    for (let i = 1; i <= calcHours; i++) {
       let hourRate = baseRate * timeMultiplier;
       if (i === 1) hourlySum += hourRate * 1.0;
       else if (i >= 2 && i <= 3) hourlySum += hourRate * 0.9;
       else if (i >= 4 && i <= 6) hourlySum += hourRate * 0.8;
       else hourlySum += hourRate * 0.7;
    }

    // Cap Harian: Max 10x Base Rate
    let dailyCap = baseRate * 10;
    if (hourlySum > dailyCap) hourlySum = dailyCap;

    let subtotal = hourlySum;
    let progressiveSaving = (baseRate * timeMultiplier * calcHours) - hourlySum;

    // 5. Membership Discount
    let membershipDiscRate = 0;
    let pointsPer1000 = 0;
    let freeAdmin = false;
    let freeFine = false;
    
    if (membership === 'Basic') { membershipDiscRate = 0.05; pointsPer1000 = 1; }
    else if (membership === 'Silver') { membershipDiscRate = 0.10; pointsPer1000 = 2; freeAdmin = true; }
    else if (membership === 'Gold') { membershipDiscRate = 0.20; pointsPer1000 = 3; freeAdmin = true; freeFine = true; }
    else if (membership === 'Platinum') { membershipDiscRate = 0.30; pointsPer1000 = 5; freeAdmin = true; freeFine = true; }

    // 6. Voucher Logic
    let voucherDiscPercent = 0;
    let voucherDiscCap = 0;
    let firstHourFree = false;
    let voucherValid = false;

    if (voucherCode === 'PERDANA') { voucherDiscPercent = 0.15; voucherDiscCap = 20000; voucherValid = true; }
    else if (voucherCode === 'HEMAT50') { voucherDiscPercent = 0.50; voucherDiscCap = 15000; voucherValid = true; }
    else if (voucherCode === 'GRATIS1') { firstHourFree = true; voucherValid = true; }
    else if (voucherCode === 'MALAM25' && (entryHour >= 20 || entryHour < 5)) { voucherDiscPercent = 0.25; voucherValid = true; }
    else if (voucherCode === 'VIPDAY') { voucherValid = true; } // VIPDAY already applied in baseRate

    // Compare Membership vs Voucher (Choose Largest)
    let membershipDiscVal = subtotal * membershipDiscRate;
    let voucherDiscVal = 0;
    if (firstHourFree) {
       voucherDiscVal = baseRate * timeMultiplier;
    } else {
       voucherDiscVal = subtotal * voucherDiscPercent;
       if (voucherDiscCap > 0 && voucherDiscVal > voucherDiscCap) voucherDiscVal = voucherDiscCap;
    }

    let finalDiscount = membershipDiscVal;
    let appliedLabel = membership;
    if (voucherDiscVal > membershipDiscVal) {
      finalDiscount = voucherDiscVal;
      appliedLabel = `Voucher ${voucherCode}`;
    }

    // 7. Fees & Penalties
    let adminFee = freeAdmin ? 0 : 1000;
    let lostTicketPenalty = (isTicketLost && !freeFine) ? 50000 : 0;
    let evFee = isEvCharging ? 5000 * calcHours : 0;
    let valetFee = isValet ? 20000 : 0;

    let subTotalWithFees = subtotal - finalDiscount + lostTicketPenalty + evFee + valetFee + adminFee;
    let tax = subTotalWithFees * 0.10;
    let totalUnrounded = subTotalWithFees + tax;

    // Pembulatan Atas ke 500
    let total = Math.ceil(totalUnrounded / 500) * 500;
    let rounding = total - totalUnrounded;

    // Loyalty Points
    let pointsEarned = Math.floor(total / 1000) * pointsPer1000;
    let change = paymentAmount - total;
    if (paymentAmount === 0) change = 0;

    // CO2 Estimation (Standard rates: ~0.15kg/hour idling/parking overhead)
    let co2 = (calcHours * 0.12).toFixed(2);

    return {
      durHours: Math.floor(totalMinutes / 60),
      durMinutes: totalMinutes % 60,
      calcHours,
      baseRate,
      timeMultiplier,
      timeLabel,
      subtotal,
      progressiveSaving,
      finalDiscount,
      appliedLabel,
      lostTicketPenalty,
      evFee,
      valetFee,
      adminFee,
      tax,
      rounding,
      total,
      change,
      pointsEarned,
      co2,
      isVoucherValid: voucherValid || voucherCode === '',
      paymentValid: paymentAmount >= total || paymentAmount === 0
    };
  }, [
    vehicleType, parkingZone, entryHour, entryMinute, exitHour, exitMinute, 
    membership, voucherCode, isTicketLost, isEvCharging, isValet, paymentAmount
  ]);

  const progressToNextTier = useMemo(() => {
    if (membership === 'Platinum') return 100;
    if (membership === 'Gold') return 80;
    if (membership === 'Silver') return 60;
    if (membership === 'Basic') return 40;
    return 20;
  }, [membership]);

  return (
    <div className="min-h-screen bg-pos-bg flex flex-col items-center justify-center p-4 lg:p-8 font-sans">
      <header className="w-full max-w-6xl mb-8 flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <h1 className="text-4xl font-bold tracking-tighter text-white flex items-center gap-3">
            <MapPin className="text-pos-accent animate-pulse" />
            SMARTPARK OS <span className="text-xs font-mono px-2 py-0.5 bg-pos-accent text-pos-bg rounded">v2.0</span>
          </h1>
          <p className="text-slate-400 font-mono text-sm">Enterprise Parking Management System</p>
        </div>
        <div className="flex items-center gap-6 bg-pos-surface p-3 rounded-xl border border-pos-border">
          <div className="text-right">
            <p className="text-xs uppercase text-slate-500 font-bold tracking-widest">Operator</p>
            <p className="text-pos-accent font-mono">{cashierName || 'No Name'}</p>
          </div>
          <div className="h-8 w-[1px] bg-pos-border"></div>
          <div className="text-right">
            <p className="text-xs uppercase text-slate-500 font-bold tracking-widest">Time</p>
            <p className="text-white font-mono">{new Date().toLocaleTimeString('id-ID', { hour12: false })}</p>
          </div>
        </div>
      </header>

      <main className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        {/* --- INPUT LAYER --- */}
        <motion.section 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-pos-surface border border-pos-border rounded-2xl p-6 shadow-2xl"
        >
          <div className="flex items-center gap-2 mb-6 pb-4 border-b border-pos-border">
            <CreditCard className="text-pos-accent" />
            <h2 className="text-xl font-bold">Transaction Input</h2>
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs uppercase font-bold text-slate-500 tracking-wider">Kasir</label>
                <input 
                  type="text" 
                  placeholder="Nama Kasir..." 
                  value={cashierName}
                  onChange={(e) => setCashierName(e.target.value)}
                  className="w-full bg-pos-bg border border-pos-border rounded-lg p-3 text-white focus:border-pos-accent outline-none font-mono"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase font-bold text-slate-500 tracking-wider">Membership</label>
                <select 
                  value={membership}
                  onChange={(e) => setMembership(e.target.value)}
                  className="w-full bg-pos-bg border border-pos-border rounded-lg p-3 text-white focus:border-pos-accent outline-none appearance-none font-mono"
                >
                  <option>Guest</option>
                  <option>Basic</option>
                  <option>Silver</option>
                  <option>Gold</option>
                  <option>Platinum</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-2">
                <label className="text-xs uppercase font-bold text-slate-500 tracking-wider">Kendaraan</label>
                <div className="grid grid-cols-5 gap-2">
                  {[
                    { id: 'Motor', icon: Bike },
                    { id: 'Mobil', icon: Car },
                    { id: 'SUV', icon: Car },
                    { id: 'Bus', icon: BusIcon },
                    { id: 'Truk', icon: Truck }
                  ].map((v) => (
                    <button
                      key={v.id}
                      onClick={() => setVehicleType(v.id)}
                      className={`flex flex-col items-center justify-center p-2 rounded-lg border transition-all ${vehicleType === v.id ? 'bg-pos-accent/20 border-pos-accent text-pos-accent' : 'bg-pos-bg border-pos-border text-slate-500 hover:border-slate-500'}`}
                    >
                      <v.icon size={20} />
                      <span className="text-[10px] mt-1 font-bold">{v.id}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase font-bold text-slate-500 tracking-wider">Zona</label>
                <div className="grid grid-cols-3 gap-2">
                  {['A', 'B', 'C'].map((z) => (
                    <button
                      key={z}
                      onClick={() => setParkingZone(z)}
                      className={`p-3 rounded-lg border font-bold transition-all ${parkingZone === z ? 'bg-pos-accent/20 border-pos-accent text-pos-accent' : 'bg-pos-bg border-pos-border text-slate-500 hover:border-slate-500'}`}
                    >
                      {z}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-4">
                <label className="text-xs uppercase font-bold text-slate-500 tracking-wider flex items-center gap-2">
                  <Clock size={14} /> Jam Masuk
                </label>
                <div className="flex items-center gap-2">
                  <input 
                    type="number" min="0" max="23" value={entryHour}
                    onChange={(e) => setEntryHour(Number(e.target.value))}
                    className="w-full bg-pos-bg border border-pos-border rounded-lg p-2 text-white font-mono text-center"
                  />
                  <span className="font-bold">:</span>
                  <input 
                    type="number" min="0" max="59" value={entryMinute}
                    onChange={(e) => setEntryMinute(Number(e.target.value))}
                    className="w-full bg-pos-bg border border-pos-border rounded-lg p-2 text-white font-mono text-center"
                  />
                </div>
              </div>
               <div className="space-y-4">
                <label className="text-xs uppercase font-bold text-slate-500 tracking-wider flex items-center gap-2">
                  <Clock size={14} /> Jam Keluar
                </label>
                <div className="flex items-center gap-2">
                  <input 
                    type="number" min="0" max="23" value={exitHour}
                    onChange={(e) => setExitHour(Number(e.target.value))}
                    className="w-full bg-pos-bg border border-pos-border rounded-lg p-2 text-white font-mono text-center"
                  />
                  <span className="font-bold">:</span>
                  <input 
                    type="number" min="0" max="59" value={exitMinute}
                    onChange={(e) => setExitMinute(Number(e.target.value))}
                    className="w-full bg-pos-bg border border-pos-border rounded-lg p-2 text-white font-mono text-center"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs uppercase font-bold text-slate-500 tracking-wider">Voucher Code</label>
                <input 
                  type="text" 
                  placeholder="Ketik kode..." 
                  value={voucherCode}
                  onChange={(e) => setVoucherCode(e.target.value.toUpperCase())}
                  className="w-full bg-pos-bg border border-pos-border rounded-lg p-3 text-white focus:border-pos-accent outline-none font-mono"
                />
              </div>
              <div className="flex flex-col justify-center gap-3">
                <label className="flex items-center gap-3 cursor-pointer group">
                  <div className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${isTicketLost ? 'bg-red-500 border-red-500' : 'bg-pos-bg border-pos-border group-hover:border-slate-500'}`}>
                    {isTicketLost && <ShieldAlert size={14} className="text-white" />}
                  </div>
                  <input type="checkbox" checked={isTicketLost} onChange={(e) => setIsTicketLost(e.target.checked)} className="hidden" />
                  <span className="text-sm font-bold text-slate-300">Tiket Hilang?</span>
                </label>
                 <div className="flex gap-4">
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <div className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${isEvCharging ? 'bg-pos-accent border-pos-accent' : 'bg-pos-bg border-pos-border group-hover:border-slate-500'}`}>
                      {isEvCharging && <Zap size={14} className="text-white" />}
                    </div>
                    <input type="checkbox" checked={isEvCharging} onChange={(e) => setIsEvCharging(e.target.checked)} className="hidden" />
                    <span className="text-xs font-bold text-slate-300">EV Charge</span>
                  </label>
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <div className={`w-5 h-5 rounded border flex items-center justify-center transition-all ${isValet ? 'bg-pos-accent border-pos-accent' : 'bg-pos-bg border-pos-border group-hover:border-slate-500'}`}>
                      {isValet && <Star size={14} className="text-white" />}
                    </div>
                    <input type="checkbox" checked={isValet} onChange={(e) => setIsValet(e.target.checked)} className="hidden" />
                    <span className="text-xs font-bold text-slate-300">Valet</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t border-pos-border">
              <div className="flex justify-between items-end">
                <div className="space-y-1">
                   <label className="text-xs uppercase font-bold text-slate-500 tracking-wider">Nominal Bayar</label>
                   <input 
                    type="number" 
                    placeholder="Contoh: 50000" 
                    value={paymentAmount || ''}
                    onChange={(e) => setPaymentAmount(Number(e.target.value))}
                    className="w-full bg-pos-bg border border-pos-border rounded-lg p-3 text-white focus:border-pos-accent outline-none font-mono text-xl"
                  />
                </div>
                {!report.paymentValid && (
                  <p className="text-pos-error text-[10px] font-mono font-bold animate-bounce">PEMBAYARAN TIDAK CUKUP</p>
                )}
              </div>
              
              <button 
                onClick={() => setShowReceipt(true)}
                disabled={!report.paymentValid || !cashierName}
                className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-3 transition-all ${(!report.paymentValid || !cashierName) ? 'bg-slate-700 text-slate-500 cursor-not-allowed' : 'bg-pos-accent text-pos-bg hover:scale-[1.02] shadow-lg shadow-pos-accent/20'}`}
              >
                <Receipt size={20} />
                CETAK STRUK SEKARANG
              </button>
            </div>
          </div>
        </motion.section>

        {/* --- RECEIPT ENGINE --- */}
        <section className="relative min-h-[700px]">
          <AnimatePresence mode="wait">
            {!showReceipt ? (
              <motion.div 
                key="placeholder"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex flex-col items-center justify-center border-2 border-dashed border-pos-border rounded-2xl bg-pos-surface/30 px-12 text-center"
              >
                <div className="w-16 h-16 rounded-full bg-pos-bg border border-pos-border flex items-center justify-center mb-4">
                  <Receipt className="text-pos-border" />
                </div>
                <h3 className="text-slate-500 font-bold">Menunggu Input Data</h3>
                <p className="text-slate-600 text-sm mt-2">Lengkapi parameter di sebelah kiri untuk melihat rincian biaya real-time</p>
              </motion.div>
            ) : (
              <motion.div 
                key="receipt"
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ type: 'spring', damping: 20 }}
                className="receipt-paper w-full p-8 font-mono text-xs uppercase"
              >
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold tracking-[0.2em] mb-1">🅿 SMARTPARK OS</h2>
                  <p className="text-[10px]">Powered by SmartPark v2.0</p>
                  <p className="mt-2 tracking-widest leading-none">------------------------------------------</p>
                </div>

                <div className="space-y-1 mb-6">
                  <div className="flex justify-between">
                    <span>Kasir</span>
                    <span>: {cashierName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Trx ID</span>
                    <span>: SP-{Date.now().toString().slice(-6)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Kendaraan</span>
                    <span>: {vehicleType} — Zona {parkingZone}</span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span>Masuk</span>
                    <span>: {String(entryHour).padStart(2, '0')}:{String(entryMinute).padStart(2, '0')}</span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span>Keluar</span>
                    <span>: {String(exitHour).padStart(2, '0')}:{String(exitMinute).padStart(2, '0')}</span>
                  </div>
                  <div className="flex justify-between italic">
                    <span>Durasi</span>
                    <span>: {report.durHours} Jam {report.durMinutes} Menit</span>
                  </div>
                </div>

                <div className="space-y-2 border-y border-dashed border-slate-300 py-4 mb-6">
                  <p className="font-bold border-b border-dashed border-slate-200 pb-2 mb-2">Rincian Biaya</p>
                  <div className="flex justify-between">
                    <span>Tarif Dasar ({report.calcHours} Jam)</span>
                    <span>Rp {(report.baseRate * report.calcHours).toLocaleString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Multiplier Waktu ({report.timeLabel})</span>
                    <span>×{report.timeMultiplier}</span>
                  </div>
                  {report.progressiveSaving > 0 && (
                    <div className="flex justify-between text-pos-success">
                      <span>Progressive Saving</span>
                      <span>-Rp {report.progressiveSaving.toLocaleString('id-ID')}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between pt-2 mt-2 border-t border-slate-100">
                    <span>Subtotal</span>
                    <span>Rp {report.subtotal.toLocaleString('id-ID')}</span>
                  </div>
                  
                  {report.finalDiscount > 0 && (
                     <div className="flex justify-between text-pos-success font-bold">
                      <span>Diskon [{report.appliedLabel}]</span>
                      <span>-Rp {report.finalDiscount.toLocaleString('id-ID')}</span>
                    </div>
                  )}

                  {report.lostTicketPenalty > 0 && (
                    <div className="flex justify-between text-pos-error">
                      <span>Denda Tiket Hilang</span>
                      <span>Rp {report.lostTicketPenalty.toLocaleString('id-ID')}</span>
                    </div>
                  )}

                  {report.evFee > 0 && (
                    <div className="flex justify-between">
                      <span>EV Charging ({report.calcHours} Jam)</span>
                      <span>Rp {report.evFee.toLocaleString('id-ID')}</span>
                    </div>
                  )}

                  {report.valetFee > 0 && (
                    <div className="flex justify-between">
                      <span>Layanan Valet</span>
                      <span>Rp {report.valetFee.toLocaleString('id-ID')}</span>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <span>Biaya Admin</span>
                    <span>Rp {report.adminFee.toLocaleString('id-ID')}</span>
                  </div>

                  <div className="flex justify-between">
                    <span>Pajak 10%</span>
                    <span>Rp {Math.floor(report.tax).toLocaleString('id-ID')}</span>
                  </div>

                  {report.rounding !== 0 && (
                    <div className="flex justify-between">
                      <span>Pembulatan</span>
                      <span>Rp {Math.ceil(report.rounding).toLocaleString('id-ID')}</span>
                    </div>
                  )}
                </div>

                <div className="flex justify-between text-2xl font-bold mb-6">
                  <span>TOTAL</span>
                  <span className="text-pos-bg underline decoration-double">Rp {report.total.toLocaleString('id-ID')}</span>
                </div>

                <div className="space-y-1 mb-8">
                  <div className="flex justify-between">
                    <span>Bayar</span>
                    <span>Rp {paymentAmount.toLocaleString('id-ID')}</span>
                  </div>
                  <div className="flex justify-between font-bold">
                    <span>Kembalian</span>
                    <span>Rp {report.change.toLocaleString('id-ID')}</span>
                  </div>
                </div>

                <div className="bg-slate-50 p-3 rounded border border-slate-200 mb-4">
                  <p className="font-bold flex items-center gap-2 mb-2">💎 Loyalty Summary</p>
                  <div className="flex justify-between mb-1">
                    <span>Poin Didapat</span>
                    <span className="font-bold text-pos-accent">+{report.pointsEarned} Poin</span>
                  </div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mb-1">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${progressToNextTier}%` }}
                      className="bg-pos-accent h-full"
                    />
                  </div>
                  <p className="text-[8px] text-slate-500">Progress ke {membership === 'Platinum' ? 'MAX' : 'Tier Selanjutnya'}: {progressToNextTier}%</p>
                </div>

                <div className="space-y-3">
                  <div className="flex gap-2 items-start bg-blue-50 p-2 rounded text-[10px]">
                    <AlertCircle size={14} className="text-blue-500 shrink-0" />
                    <div>
                      <p className="font-bold text-blue-800 tracking-normal">💡 Insight</p>
                      <p className="text-blue-600 tracking-normal italic">Kamu hemat Rp {(report.progressiveSaving + report.finalDiscount).toLocaleString('id-ID')} vs non-member. Parkir lebih hemat datang jam 13:00!</p>
                    </div>
                  </div>

                  <div className="flex gap-2 items-start bg-green-50 p-2 rounded text-[10px]">
                    <Leaf size={14} className="text-green-500 shrink-0" />
                    <div>
                      <p className="font-bold text-green-800 tracking-normal">🌿 Eco Report</p>
                      <p className="text-green-600 tracking-normal">Estimasi emisi: {report.co2} kg CO₂. Consider EV for next visit!</p>
                    </div>
                  </div>
                </div>

                <div className="text-center mt-8 pt-6 border-t border-dashed border-slate-300">
                  <p className="font-bold mb-1">Terima kasih telah menggunakan</p>
                  <p className="font-bold text-lg mb-1">SmartPark OS! 🚀</p>
                  <p className="text-slate-400">"Park Smart, Live Better"</p>
                </div>

                <button 
                  onClick={() => setShowReceipt(false)}
                  className="mt-6 w-full py-2 bg-slate-100 text-slate-400 rounded hover:bg-slate-200 transition-colors border border-slate-200"
                >
                  Edit Input Data
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </main>

      <footer className="mt-12 text-slate-600 text-[10px] font-mono flex items-center gap-4">
        <span className="flex items-center gap-1"><CheckCircle2 size={12} /> System Status: Online</span>
        <span className="flex items-center gap-1"><ShieldAlert size={12} /> Encrypted Session</span>
        <span>© 2024 SmartPark Global Inc.</span>
      </footer>
    </div>
  );
}
